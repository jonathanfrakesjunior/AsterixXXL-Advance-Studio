@echo off
title Asterix XXL Advance Studio
cd /d "%~dp0"
echo.
echo   Asterix XXL Advance Studio wird geoeffnet ...
echo.
start "" "%~dp0index.html"
echo   Falls sich nichts oeffnet: index.html doppelklicken
echo   oder per Rechtsklick mit Chrome / Edge / Firefox oeffnen.
timeout /t 4 >nul
