/* Asterix XXL Advance Studio - ui_img.js : gemeinsame Bild-Werkzeuge */
(function (global) {
'use strict';
var G = global.AXS, el = G.el;

/* Median-Cut: bis zu n Farben aus einem RGBA-Bild */
function medianCut(rgba, n, skipTransparent) {
  var px = [];
  for (var i = 0; i < rgba.length; i += 4) {
    if (skipTransparent && rgba[i + 3] < 128) continue;
    px.push([rgba[i] & 0xF8, rgba[i + 1] & 0xF8, rgba[i + 2] & 0xF8]);
  }
  if (!px.length) return [[0, 0, 0]];
  var boxes = [px];
  while (boxes.length < n) {
    var bi = -1, br = -1, bc = 0;
    boxes.forEach(function (b, k) {
      if (b.length < 2) return;
      for (var c = 0; c < 3; c++) {
        var mn = 255, mx = 0;
        for (var j = 0; j < b.length; j++) { var v = b[j][c]; if (v < mn) mn = v; if (v > mx) mx = v; }
        if (mx - mn > br) { br = mx - mn; bi = k; bc = c; }
      }
    });
    if (bi < 0 || br <= 0) break;
    var box = boxes[bi];
    box.sort(function (a, b) { return a[bc] - b[bc]; });
    var mid = box.length >> 1;
    boxes.splice(bi, 1, box.slice(0, mid), box.slice(mid));
  }
  return boxes.map(function (b) {
    var r = 0, g = 0, bl = 0;
    b.forEach(function (p) { r += p[0]; g += p[1]; bl += p[2]; });
    return [Math.round(r / b.length), Math.round(g / b.length), Math.round(bl / b.length)];
  });
}
G.medianCut = medianCut;

/* Farben in eine Palettendatei schreiben (Slot 0-255 = BG, 256-511 = OBJ) */
function writePalColors(fileOff, startSlot, colors) {
  var d = G.App.rom.data, f = G.parsePalFile(d, fileOff), written = 0;
  colors.forEach(function (c, k) {
    var slot = startSlot + k;
    f.recs.forEach(function (r) {
      var s0 = r.dst >> 1;
      if (slot >= s0 && slot < s0 + r.n) { G.putU16(d, r.off + 2 * (slot - s0), G.rgbToC15(c[0], c[1], c[2])); written++; }
    });
  });
  return written;
}
function palFileSlots(fileOff) {
  var f = G.parsePalFile(G.App.rom.data, fileOff), s = [];
  f.recs.forEach(function (r) { for (var k = 0; k < r.n; k++) s.push((r.dst >> 1) + k); });
  return s;
}
G.writePalColors = writePalColors; G.palFileSlots = palFileSlots;

/* Export als indiziertes PNG */
function exportPNG(name, idx, w, h, pal, transparent0) {
  G.download(name, G.pngWriteIndexed(idx, w, h, pal, !!transparent0), 'image/png');
}
G.exportPNG = exportPNG;

/* Datei -> Indizes (w x h). opts: lo, hi, transparent0, dither, keepIdx(auto), allowResize */
async function importIndexed(file, w, h, pal, opts) {
  opts = opts || {};
  var im = await G.readImageFile(file);
  if (im.w !== w || im.h !== h) {
    if (!opts.allowResize) throw new Error($t('Bildgroesse ') + im.w + 'x' + im.h + $t(' passt nicht - erwartet ') + w + 'x' + h + '.');
    im = resizeRGBA(im, w, h);
  }
  var lo = opts.lo === undefined ? 0 : opts.lo, hi = opts.hi === undefined ? 255 : opts.hi;
  if (im.mode === 'P' && im.idx && opts.keepIdx !== false) {
    var bad = 0;
    for (var i = 0; i < im.idx.length; i++) {
      var v = im.idx[i];
      if (!(v === 0 && opts.transparent0) && (v < lo || v > hi)) bad++;
    }
    if (!bad) return { idx: im.idx, mode: 'indices', rgba: im.rgba };
    /* Indizes ausserhalb des Bereichs -> ueber Farben zuordnen */
  }
  return { idx: G.quantize(im.rgba, w, h, pal, lo, hi, { transparent0: opts.transparent0 }), mode: $t('farben'), rgba: im.rgba };
}
function resizeRGBA(im, w, h) {
  var c = document.createElement('canvas'); c.width = im.w; c.height = im.h;
  var cx = c.getContext('2d'), id = cx.createImageData(im.w, im.h); id.data.set(im.rgba); cx.putImageData(id, 0, 0);
  var c2 = document.createElement('canvas'); c2.width = w; c2.height = h;
  var cx2 = c2.getContext('2d'); cx2.imageSmoothingQuality = 'high'; cx2.drawImage(c, 0, 0, w, h);
  return { w: w, h: h, mode: 'RGBA', rgba: new Uint8Array(cx2.getImageData(0, 0, w, h).data.buffer) };
}
G.importIndexed = importIndexed; G.resizeRGBA = resizeRGBA;

/* Zoom-Vorschau */
function zoomView(canvas, initial) {
  var z = initial || 2, wrap = el('div', { class: 'imgbox bigprev' }, [canvas]);
  function apply() { canvas.style.width = (canvas.width * z) + 'px'; canvas.style.height = (canvas.height * z) + 'px'; }
  apply();
  var ctl = el('span', { class: 'row tight' }, [el('span', { class: 'mut', text: $t('Zoom') })]);
  [1, 2, 3, 4, 6].forEach(function (f) {
    ctl.appendChild(G.button(f + 'x', function () { z = f; apply(); Array.prototype.forEach.call(ctl.querySelectorAll('button'), function (b) { b.classList.toggle('on', b.textContent === f + 'x'); }); }, z === f ? 'on' : ''));
  });
  return { wrap: wrap, ctl: ctl, set: function (c) { canvas = c; G.clear(wrap).appendChild(c); apply(); } };
}
G.zoomView = zoomView;

/* Farbfeld-Raster einer 256er-Palette, markiert Bereich */
function palGrid(pal, lo, hi, onPick) {
  var g = el('div', { class: 'colgrid' });
  pal.forEach(function (c, i) {
    var sw = el('div', { class: 'sw' + ((i < lo || i > hi) ? ' off' : ''), title: $t('Index ') + i + $t(' - RGB ') + c.join(','), style: { background: 'rgb(' + c.join(',') + ')' } });
    if (onPick) sw.onclick = function () { onPick(i, sw); };
    g.appendChild(sw);
  });
  return g;
}
G.palGrid = palGrid;

/* VC-Block ersetzen (komprimieren, ggf. verschieben) */
function writeVC(oldOff, raw, label) {
  var d = G.App.rom.data, old = G.vcDecode(d, oldOff);
  var enc = G.vcEncode(raw);
  var res = G.replaceBlob(oldOff, old.used, enc, {});
  G.logChange(label + ': ' + (res.moved ? $t('verschoben nach ') + G.hx(res.off) + ' (' + res.refs + $t(' Verweise angepasst)') : $t('an Ort und Stelle ersetzt')) + ', ' + enc.length + $t(' Byte'));
  G.invalidate();
  return res;
}
G.writeVC = writeVC;

function hexColor(c) { return '#' + c.map(function (v) { var s = v.toString(16); return s.length < 2 ? '0' + s : s; }).join(''); }
function parseHex(h) { h = h.replace('#', ''); return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)]; }
G.hexColor = hexColor; G.parseHex = parseHex;

/* Kleine Hilfen fuer Kacheln/Objekte */
function obj4ToIdx(buf, tileStart, ntiles, colsTiles, bank) {
  var rows = Math.ceil(ntiles / colsTiles), w = colsTiles * 8, h = rows * 8, idx = new Uint8Array(w * h);
  for (var t = 0; t < ntiles; t++) {
    var tx = (t % colsTiles) * 8, ty = ((t / colsTiles) | 0) * 8, o = (tileStart + t) * 32;
    for (var y = 0; y < 8; y++) for (var x = 0; x < 8; x++) {
      var b = buf[o + y * 4 + (x >> 1)], v = (x & 1) ? (b >> 4) : (b & 15);
      idx[(ty + y) * w + tx + x] = v ? v + bank * 16 : 0;
    }
  }
  return { idx: idx, w: w, h: h };
}
function idxToObj4(idx, w, ntiles, colsTiles, out, tileStart) {
  for (var t = 0; t < ntiles; t++) {
    var tx = (t % colsTiles) * 8, ty = ((t / colsTiles) | 0) * 8, o = (tileStart + t) * 32;
    for (var y = 0; y < 8; y++) for (var x = 0; x < 8; x += 2) {
      var a = idx[(ty + y) * w + tx + x] & 15, b = idx[(ty + y) * w + tx + x + 1] & 15;
      out[o + y * 4 + (x >> 1)] = a | (b << 4);
    }
  }
  return out;
}
G.obj4ToIdx = obj4ToIdx; G.idxToObj4 = idxToObj4;

})(window);
