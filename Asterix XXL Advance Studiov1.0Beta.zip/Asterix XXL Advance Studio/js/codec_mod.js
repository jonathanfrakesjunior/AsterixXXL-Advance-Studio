/* Asterix XXL Advance Studio - codec_mod.js
   Musik von "LS_Play (C) Logik State 2003": Songs im Format "GBAMOD30".
   Asterix XXL: gegenueber Driv3r steht bei 0x34 zusaetzlich u32 Mischrate (10512); alle folgenden
   Felder liegen daher 4 Byte weiter hinten (SH = G.K.SONG_SHIFT). Driv3r-Aufbau (SH = 0):
   Kopf (0x650 Byte):
     0x00 "GBAMOD30"   0x08 Name (32)   0x28 u32 Kanaele   0x2C/0x30 u32 ?
     0x34 u32 Anzahl Orders   0x38 u8[256] Sample-Vorladeliste
     0x138 u32 Patterns  0x13C u32 Gesamtlautstaerke  0x140 u32 ?  0x144 u32 Tempo  0x148 u32 Speed
     0x14C u8[256] Orders   0x24C u32[256] Pattern-Offsets (relativ zu 0x650)
   Pattern: je Kanal ein Block {u32 w1, w1, w2, w3, w4} + Daten (64 Zeilen):
     Strom 0 (16 Bit RLE: Anzahl, Hi, Lo): Note<<7 | Instrument (Note 0x1FF = leer)
     Strom 1 (8 Bit RLE, ab w1): Lautstaerke+1 (0 = keine)
     Strom 2 (16 Bit RLE, ab w2): Effekt<<8 | Parameter
     Jeder Strom endet mit Anzahl 0; w3 = Ende, w4 = auf 4 gerundete Blockgroesse.
   Noten wie XM: 49 = C-4 (entspricht MIDI 60). Instrument = Sample-Nummer (1-basiert). */
(function (global) {
'use strict';
var G = global.AXS;
var ROWS = 64, NOTE_NONE = 0x1FF;

function rle(d, o, wide) {
  var out = [];
  while (out.length < ROWS) {
    var c = d[o], v;
    if (wide) { v = (d[o + 1] << 8) | d[o + 2]; o += 3; } else { v = d[o + 1]; o += 2; }
    if (c === 0) { while (out.length < ROWS) out.push(v); break; }
    for (var i = 0; i < c && out.length < ROWS; i++) out.push(v);
  }
  return out;
}
function isSong(d, off) {
  var m = 'GBAMOD30';
  for (var i = 0; i < 8; i++) if (d[off + i] !== m.charCodeAt(i)) return false;
  return true;
}
function parseSong(d, off) {
  var SH = G.K.SONG_SHIFT || 0;
  if (!isSong(d, off)) throw new Error($t('kein GBAMOD30-Song bei ') + G.hx(off));
  var u32 = function (o) { return G.u32(d, off + o); };
  var s = {
    name: d.slice(off + 8, off + 0x28), nch: u32(0x28), u2c: u32(0x2C), u30: u32(0x30),
    smap: d.slice(off + (0x38 + SH), off + (0x138 + SH)), npat: u32((0x138 + SH)), gvol: u32((0x13C + SH)), u140: u32((0x140 + SH)),
    tempo: u32((0x144 + SH)), speed: u32((0x148 + SH)), mix: SH ? u32(0x34) : 0, orders: [], pats: []
  };
  var nord = u32((0x34 + SH));
  for (var i = 0; i < nord; i++) s.orders.push(d[off + (0x14C + SH) + i]);
  var base = off + (0x650 + SH), end = base;
  for (var p = 0; p < s.npat; p++) {
    var o = base + u32((0x24C + SH) + 4 * p), chans = [];
    for (var c = 0; c < s.nch; c++) {
      var w1 = G.u32(d, o + 4), w2 = G.u32(d, o + 8), w4 = G.u32(d, o + 16), r = o + 20;
      var s0 = rle(d, r, true), s1 = rle(d, r + w1, false), s2 = rle(d, r + w2, true), rows = [];
      for (var k = 0; k < ROWS; k++) rows.push({ note: s0[k] >> 7, inst: s0[k] & 0x7F, vol: s1[k], fx: s2[k] >> 8, par: s2[k] & 255 });
      chans.push(rows);
      o = r + w4;
      if (o > end) end = o;
    }
    s.pats.push(chans);
  }
  s.size = end - off;
  return s;
}

function encRle(vals, wide) {
  var out = [], i = 0;
  while (i < vals.length) {
    var j = i;
    while (j < vals.length && vals[j] === vals[i] && j - i < 255) j++;
    out.push(j - i);
    if (wide) out.push((vals[i] >> 8) & 255, vals[i] & 255); else out.push(vals[i] & 255);
    i = j;
  }
  out.push(0);
  return out;
}
function buildSong(s) {
  var SH = G.K.SONG_SHIFT || 0;
  var parts = [], offs = [], pos = 0;
  s.pats.forEach(function (chans) {
    offs.push(pos);
    chans.forEach(function (rows) {
      var s0 = [], s1 = [], s2 = [];
      rows.forEach(function (r) {
        s0.push(((r.note & 0x1FF) << 7) | (r.inst & 0x7F));
        s1.push(r.vol & 255); s2.push(((r.fx & 255) << 8) | (r.par & 255));
      });
      var a = encRle(s0, true), b = encRle(s1, false), c = encRle(s2, true);
      var w1 = a.length, w2 = w1 + b.length, w3 = w2 + c.length, w4 = (w3 + 3) & ~3;
      var blk = new Uint8Array(20 + w4);
      G.putU32(blk, 0, w1); G.putU32(blk, 4, w1); G.putU32(blk, 8, w2); G.putU32(blk, 12, w3); G.putU32(blk, 16, w4);
      blk.set(a, 20); blk.set(b, 20 + w1); blk.set(c, 20 + w2);
      parts.push(blk); pos += blk.length;
    });
  });
  var out = new Uint8Array((0x650 + SH) + pos);
  'GBAMOD30'.split('').forEach(function (ch, i) { out[i] = ch.charCodeAt(0); });
  if (s.name) out.set(s.name.subarray(0, 32), 8);
  G.putU32(out, 0x28, s.nch); G.putU32(out, 0x2C, s.u2c || 0); G.putU32(out, 0x30, s.u30 || 0);
  if (SH) G.putU32(out, 0x34, s.mix || 10512);
  G.putU32(out, (0x34 + SH), s.orders.length);
  if (s.smap) out.set(s.smap.subarray(0, 256), (0x38 + SH));
  G.putU32(out, (0x138 + SH), s.pats.length); G.putU32(out, (0x13C + SH), s.gvol === undefined ? 64 : s.gvol);
  G.putU32(out, (0x140 + SH), s.u140 || 0); G.putU32(out, (0x144 + SH), s.tempo); G.putU32(out, (0x148 + SH), s.speed);
  for (var i = 0; i < 256; i++) out[(0x14C + SH) + i] = i < s.orders.length ? s.orders[i] : (i === s.orders.length ? 0xFF : 0);
  offs.forEach(function (o, k) { G.putU32(out, (0x24C + SH) + 4 * k, o); });
  var p = (0x650 + SH);
  parts.forEach(function (b) { out.set(b, p); p += b.length; });
  return out;
}
function emptyRows() { var r = []; for (var i = 0; i < ROWS; i++) r.push({ note: NOTE_NONE, inst: 0, vol: 0, fx: 0, par: 0 }); return r; }
function usedSamples(s) {
  var u = {};
  s.pats.forEach(function (ch) { ch.forEach(function (rows) { rows.forEach(function (r) { if (r.inst) u[r.inst] = 1; }); }); });
  return Object.keys(u).map(Number).sort(function (a, b) { return a - b; });
}
function makeSmap(list) { var m = new Uint8Array(256), k = 1; list.forEach(function (x) { if (k < 256) m[k++] = x; }); return m; }

var NN = ['C-', 'C#', 'D-', 'D#', 'E-', 'F-', 'F#', 'G-', 'G#', 'A-', 'A#', 'B-'];
function noteName(n) { if (n === NOTE_NONE || n === 0) return '---'; if (n === 97) return '==='; n -= 1; return NN[n % 12] + ((n / 12) | 0); }

/* ---------------------------------------------------------------- Wiedergabe */
/* samples: [{data:Int8Array, loopStart, loopLen, vol, fine, rel}] Index = Instrument-1 */
function renderSong(s, samples, opts) {
  opts = opts || {};
  var rate = opts.rate || 22050, maxSec = opts.maxSec || 600;
  var speed = s.speed || 6, tempo = s.tempo || 125;
  var nch = s.nch, ch = [];
  for (var c = 0; c < nch; c++) ch.push({ smp: null, pos: 0, step: 0, vol: 0, note: 0, active: false, slide: 0, porta: 0, target: 0, pitch: 0 });
  var outL = [], outR = [];
  var ord = 0, row = 0, visited = {}, total = 0, maxFrames = rate * maxSec;
  function freqOf(c) {
    var smpv = c.smp; if (!smpv) return 0;
    return 8363 * Math.pow(2, (c.pitch + smpv.rel - 49 + smpv.fine / 128) / 12);
  }
  while (ord < s.orders.length && total < maxFrames) {
    var key = ord + ':' + row;
    if (visited[key]) break;          /* Song beginnt von vorn -> fertig */
    visited[key] = 1;
    var pat = s.pats[s.orders[ord]] || [], jumpOrd = -1, breakRow = -1;
    for (var c2 = 0; c2 < nch; c2++) {
      var cs = ch[c2], r = (pat[c2] || emptyRows())[row];
      cs.slide = 0; cs.portaStep = 0;
      if (r.inst && samples[r.inst - 1]) { cs.smp = samples[r.inst - 1]; cs.vol = cs.smp.vol; }
      if (r.note !== NOTE_NONE && r.note > 0 && r.note < 97) {
        if (r.fx === 3 && cs.active) { cs.target = r.note; }
        else { cs.note = r.note; cs.pitch = r.note; cs.pos = 0; cs.active = !!cs.smp; if (r.fx === 9 && r.par) cs.pos = r.par * 256; }
      } else if (r.note === 97) cs.active = false;
      if (r.vol) cs.vol = Math.min(64, r.vol - 1);
      switch (r.fx) {
        case 0x1: cs.portaStep = (r.par || 0) / 16; break;
        case 0x2: cs.portaStep = -(r.par || 0) / 16; break;
        case 0x3: cs.portaStep = (r.par || 4) / 16; cs.tone = true; break;
        case 0xA: if (r.par) cs.slide = (r.par >> 4) ? (r.par >> 4) : -(r.par & 15); break;
        case 0xB: jumpOrd = r.par; break;
        case 0xC: cs.vol = Math.min(64, r.par); break;
        case 0xD: breakRow = (r.par >> 4) * 10 + (r.par & 15); break;
        case 0xF: if (r.par) { if (r.par < 32) speed = r.par; else tempo = r.par; } break;
      }
    }
    var tickFrames = Math.round(rate * 2.5 / tempo);
    for (var t = 0; t < speed; t++) {
      if (t > 0) ch.forEach(function (cs) {
        if (cs.slide) cs.vol = Math.max(0, Math.min(64, cs.vol + cs.slide));
        if (cs.portaStep) {
          if (cs.tone) { if (cs.pitch < cs.target) cs.pitch = Math.min(cs.target, cs.pitch + Math.abs(cs.portaStep)); else cs.pitch = Math.max(cs.target, cs.pitch - Math.abs(cs.portaStep)); }
          else cs.pitch += cs.portaStep;
        }
      });
      for (var f = 0; f < tickFrames; f++) {
        var L = 0, R = 0;
        for (var c3 = 0; c3 < nch; c3++) {
          var q = ch[c3];
          if (!q.active || !q.smp) continue;
          if (f === 0) q.step = freqOf(q) / rate;
          var d = q.smp.data, ip = q.pos | 0;
          if (ip >= d.length) {
            if (q.smp.loopLen > 0) { q.pos = q.smp.loopStart + ((q.pos - q.smp.loopStart) % q.smp.loopLen); ip = q.pos | 0; }
            else { q.active = false; continue; }
          }
          var v = d[ip] / 128 * q.vol / 64;
          if (c3 % 4 === 0 || c3 % 4 === 3) { L += v * 0.8; R += v * 0.3; } else { L += v * 0.3; R += v * 0.8; }
          q.pos += q.step;
          if (q.smp.loopLen > 0 && q.pos >= q.smp.loopStart + q.smp.loopLen) q.pos -= q.smp.loopLen;
        }
        outL.push(L); outR.push(R);
      }
      total += tickFrames;
    }
    if (jumpOrd >= 0) { ord = jumpOrd; row = breakRow >= 0 ? breakRow : 0; }
    else if (breakRow >= 0) { ord++; row = breakRow; }
    else { row++; if (row >= ROWS) { row = 0; ord++; } }
  }
  /* normalisieren */
  var peak = 0.001, i;
  for (i = 0; i < outL.length; i++) peak = Math.max(peak, Math.abs(outL[i]), Math.abs(outR[i]));
  var g = Math.min(1.5, 0.9 / peak), inter = new Float32Array(outL.length * 2);
  for (i = 0; i < outL.length; i++) { inter[i * 2] = outL[i] * g; inter[i * 2 + 1] = outR[i] * g; }
  return { rate: rate, channels: 2, data: inter, seconds: outL.length / rate };
}

/* ---------------------------------------------------------------- MIDI-Export */
function songToMidi(s, opts) {
  opts = opts || {};
  var PPQ = 96, TPR = 24;                /* 4 Zeilen = 1 Viertel */
  var programs = opts.programs || {};    /* Instrument -> GM-Programm */
  var bpm = 6 * (s.tempo || 125) / (s.speed || 6);
  var tr0 = { events: [{ t: 0, data: [0xFF, 0x51, 3].concat(tempoBytes(bpm)) },
    { t: 0, data: [0xFF, 0x03].concat(G.vlq(18), strBytes('Asterix GBA Export')) }] };
  var tracks = [tr0];
  var rowsTotal = [];
  /* lineare Zeilenfolge (ohne Wiederholschleifen) */
  var seq = [], seen = {}, ord = 0, row = 0;
  while (ord < s.orders.length && seq.length < 20000) {
    var k = ord + ':' + row; if (seen[k]) break; seen[k] = 1;
    seq.push([s.orders[ord], row]);
    var pat = s.pats[s.orders[ord]] || [], jump = -1, brk = -1;
    pat.forEach(function (rows) { var r = rows[row]; if (r.fx === 0xB) jump = r.par; if (r.fx === 0xD) brk = (r.par >> 4) * 10 + (r.par & 15); });
    if (jump >= 0) { ord = jump; row = brk >= 0 ? brk : 0; }
    else if (brk >= 0) { ord++; row = brk; }
    else { row++; if (row >= ROWS) { row = 0; ord++; } }
  }
  for (var c = 0; c < s.nch; c++) {
    var mch = c >= 9 ? c + 1 : c, ev = [], cur = -1, curInst = -1, vol = 64, t = 0;
    ev.push({ t: 0, data: [0xFF, 0x03].concat(G.vlq(($t('Kanal ') + (c + 1)).length), strBytes($t('Kanal ') + (c + 1))) });
    seq.forEach(function (pr, idx) {
      var r = (s.pats[pr[0]] && s.pats[pr[0]][c]) ? s.pats[pr[0]][c][pr[1]] : null;
      t = idx * TPR;
      if (!r) return;
      if (r.vol) { vol = r.vol - 1; if (vol === 0 && cur >= 0) { ev.push({ t: t, data: [0x80 | mch, cur, 0], order: 0 }); cur = -1; } }
      if (r.note !== NOTE_NONE && r.note > 0 && r.note < 97) {
        if (cur >= 0) ev.push({ t: t, data: [0x80 | mch, cur, 0], order: 0 });
        var inst = r.inst || curInst;
        if (inst !== curInst && inst > 0) { ev.push({ t: t, data: [0xC0 | mch, (programs[inst] !== undefined ? programs[inst] : 0) & 127], order: 1 }); curInst = inst; }
        cur = Math.max(0, Math.min(127, r.note + 11));
        ev.push({ t: t, data: [0x90 | mch, cur, Math.max(1, Math.min(127, Math.round((r.vol ? r.vol - 1 : vol) * 127 / 64) || 100))], order: 2 });
      } else if (r.note === 97 && cur >= 0) { ev.push({ t: t, data: [0x80 | mch, cur, 0], order: 0 }); cur = -1; }
    });
    if (cur >= 0) ev.push({ t: seq.length * TPR, data: [0x80 | mch, cur, 0] });
    tracks.push({ events: ev });
  }
  return G.midiWrite(PPQ, tracks);
}
function tempoBytes(bpm) { var us = Math.round(60000000 / bpm); return [(us >> 16) & 255, (us >> 8) & 255, us & 255]; }
function strBytes(s) { var a = []; for (var i = 0; i < s.length; i++) a.push(s.charCodeAt(i) & 255); return a; }

/* ---------------------------------------------------------------- MIDI-Import */
/* opts: rowsPerBeat, maxCh (<=8), map: {midiCh: {inst, transpose, fixedNote}}, speed */
function midiToSong(mid, opts) {
  opts = opts || {};
  var rpb = opts.rowsPerBeat || 4, speed = opts.speed || 6, maxCh = Math.min(8, opts.maxCh || 8);
  var bpm = 60000000 / mid.tempo;
  var tempo = Math.round(bpm * rpb * speed / 24);
  var warn = [];
  if (tempo > 255) { warn.push($t('Tempo ') + tempo + $t(' zu hoch - auf 255 begrenzt (Zeilenraster verringern).')); tempo = 255; }
  if (tempo < 32) { warn.push($t('Tempo ') + tempo + $t(' zu niedrig - auf 32 angehoben.')); tempo = 32; }
  var tpr = mid.ppq / rpb;
  var notes = mid.notes.filter(function (n) { var m = opts.map && opts.map[n.ch]; return !m || m.inst !== 0; });
  /* Stimmen verteilen: pro MIDI-Kanal so viele GBA-Kanaele wie Polyphonie noetig */
  var voices = [];                         /* {ch, busyUntilRow, cells:{row:cell}} */
  var dropped = 0, maxRow = 0;
  notes.forEach(function (n) {
    var r0 = Math.round(n.t / tpr), r1 = Math.max(r0 + 1, Math.round((n.t + n.dur) / tpr));
    var v = null;
    for (var i = 0; i < voices.length; i++) if (voices[i].ch === n.ch && voices[i].busy <= r0) { v = voices[i]; break; }
    if (!v) for (var j = 0; j < voices.length; j++) if (voices[j].busy <= r0 && voices[j].ch === -1) { v = voices[j]; break; }
    if (!v) {
      if (voices.length >= maxCh) {
        /* freie Stimme eines anderen Kanals nehmen */
        for (var k = 0; k < voices.length; k++) if (voices[k].busy <= r0) { v = voices[k]; break; }
      } else { v = { ch: n.ch, busy: 0, cells: {} }; voices.push(v); }
    }
    if (!v) { dropped++; return; }
    v.ch = n.ch;
    var m = (opts.map && opts.map[n.ch]) || {};
    var key = m.fixedNote ? m.fixedNote : n.key + (m.transpose || 0);
    var note = Math.max(1, Math.min(96, key - 11));
    v.cells[r0] = { note: note, inst: m.inst || 1, vol: Math.max(2, Math.min(65, Math.round(n.vel * 64 / 127) + 1)), fx: 0, par: 0 };
    if (!v.cells[r1]) v.cells[r1] = { cut: true };
    v.busy = r1;
    if (r1 > maxRow) maxRow = r1;
  });
  var nrows = Math.max(ROWS, Math.ceil((maxRow + 1) / ROWS) * ROWS), npat = nrows / ROWS;
  if (npat > 255) { warn.push($t('Song zu lang - auf 255 Patterns gekuerzt.')); npat = 255; }
  var pats = [], orders = [], sig = {};
  for (var p = 0; p < npat; p++) {
    var chans = [];
    voices.forEach(function (v) {
      var rows = emptyRows();
      for (var r = 0; r < ROWS; r++) {
        var cell = v.cells[p * ROWS + r];
        if (!cell) continue;
        if (cell.cut) { if (rows[r].note === NOTE_NONE) rows[r].vol = 1; }
        else rows[r] = { note: cell.note, inst: cell.inst, vol: cell.vol, fx: 0, par: 0 };
      }
      chans.push(rows);
    });
    if (!chans.length) chans.push(emptyRows());
    var key = JSON.stringify(chans);
    if (sig[key] !== undefined) orders.push(sig[key]);
    else { sig[key] = pats.length; orders.push(pats.length); pats.push(chans); }
  }
  var song = { name: new Uint8Array(32), nch: Math.max(1, voices.length), u2c: 0, u30: 0, gvol: 64, u140: 0, tempo: tempo, speed: speed, orders: orders, pats: pats };
  song.smap = makeSmap(usedSamples(song));
  if (dropped) warn.push(dropped + $t(' Noten passten nicht in ') + maxCh + $t(' Kanaele und wurden weggelassen.'));
  return { song: song, warnings: warn, voices: voices.length };
}

G.ROWS = ROWS; G.NOTE_NONE = NOTE_NONE;
G.isSong = isSong; G.parseSong = parseSong; G.buildSong = buildSong; G.emptyRows = emptyRows;
G.usedSamples = usedSamples; G.makeSmap = makeSmap; G.noteName = noteName;
G.renderSong = renderSong; G.songToMidi = songToMidi; G.midiToSong = midiToSong;
})(window);
