/* Asterix XXL Advance Studio - lvlmodel.js : Leveldateien lesen, aendern, schreiben
   Leveldatei (VC-gepackt, wird nach 0x0202E818 entpackt):
     0x000  256 Farben Bodenpalette (BG 0-255)
     0x200  256 Textur-Deskriptoren a 9 Byte: {Seite<<4 | Typ, 4 x (u,v)}; Typ 0 = unsichtbar, 1 = Farbe (u0 = Index), 3 = Textur
            (Seite = 256 Zeilen im 256x656-Atlas der Welt)
     0xB00  u32 N (Abschnitte), u32 Startzelle (Zeile*12+Spalte), u32 Variante, u32 Zielwert fuer 100 %
     0xB10  (N+1) Querschnitte a 13 Punkte {s16 x, s16 Hoehe, s16 z}
            N*12 Zellen u16 {Deskriptor | Flags<<8}  (Viereck zwischen zwei Querschnitten)
            (N+1)*24 Byte je Querschnitt (Kamera-/Hilfsdaten, unveraendert)
            N*12 s16 Objektlisten-Koepfe je Zelle (-1 = leer, sonst Offset in den Objektbereich)
            Objektbereich: Datensaetze {s16 x, s16 Hoehe, s16 z, u8 Sichtweite, u8, | s16 naechster, u16 Typ, Daten}
            (Offsets zeigen auf "naechster"; der 8-Byte-Vorspann liegt davor.)
   Die Engine liest die Zeilen mit 0x4E Byte Abstand (Code im IWRAM ab 0x030001D4). */
(function (global) {
'use strict';
var G = global.AXS;

function s16(a, o) { return (a[o] | (a[o + 1] << 8)) << 16 >> 16; }
function p16(a, o, v) { v = Math.round(v); a[o] = v & 255; a[o + 1] = (v >> 8) & 255; }

/* Objektklassen nach Typ (Typ & 0x3F) */
var MESH_TYPES = { 0: 1, 1: 1, 9: 1, 10: 1, 11: 1, 12: 1, 13: 1, 14: 1, 16: 1, 17: 1, 18: 1, 19: 1, 20: 1, 23: 1, 26: 1, 27: 1, 28: 1, 29: 1, 30: 1, 31: 1, 32: 1 };
var ACTOR_TYPES = { 3: 34, 4: 34, 5: 34, 6: 36, 7: 34, 8: 34, 35: 30, 37: 20, 38: 20 };
function objClass(t) {
  t &= 0x3F;
  if (t === 2) return 'bill';
  if (ACTOR_TYPES[t]) return 'actor';
  if (t === 0) return 'coll';
  if (MESH_TYPES[t]) return 'mesh';
  if (t === 36) return 'special';
  return 'path';
}
G.lvlObjClass = objClass;
var CLASS_NAMES = { bill: $t('Billboard (Pflanze/Deko)'), actor: $t('Figur/Gegenstand'), coll: $t('Kollisionskoerper'), mesh: $t('3D-Objekt'), path: $t('Pfad/Gegnergruppe'), special: $t('Spezial') };
G.lvlClassNames = CLASS_NAMES;

function Level(L, raw) {
  this.L = L;
  this.load(raw);
}
Level.prototype.load = function (raw) {
  var m = raw, N = G.u32(m, 0xB00);
  if (N < 2 || N > 400) throw new Error($t('Leveldatei unplausibel (N=') + N + ')');
  this.head = m.slice(0, 0xB10);
  this.N = N;
  var A = 0xB10, Gs = A + (N + 1) * 78, B = Gs + N * 24, H = B + (N + 1) * 24, O = H + N * 24;
  if (O > m.length) throw new Error($t('Leveldatei zu kurz'));
  var V = [];
  for (var r = 0; r <= N; r++) for (var c = 0; c < 13; c++) { var o = A + (r * 13 + c) * 6; V.push({ x: s16(m, o), h: s16(m, o + 2), z: s16(m, o + 4) }); }
  var C = new Uint16Array(N * 12); for (var i = 0; i < N * 12; i++) C[i] = G.u16(m, Gs + 2 * i);
  var heads = new Int16Array(N * 12); for (var j = 0; j < N * 12; j++) heads[j] = s16(m, H + 2 * j);
  this.V = V; this.C = C; this.Bdata = m.slice(B, H); this.heads = heads; this.ob = m.slice(O);
  this.origLen = m.length;
};
Level.prototype.serialize = function () {
  var N = this.N, size = 0xB10 + (N + 1) * 78 + N * 24 + this.Bdata.length + N * 24 + this.ob.length;
  var out = new Uint8Array(size); out.set(this.head, 0);
  var p = 0xB10;
  this.V.forEach(function (v) { p16(out, p, v.x); p16(out, p + 2, v.h); p16(out, p + 4, v.z); p += 6; });
  for (var i = 0; i < N * 12; i++) { G.putU16(out, p, this.C[i]); p += 2; }
  out.set(this.Bdata, p); p += this.Bdata.length;
  for (var j = 0; j < N * 12; j++) { p16(out, p, this.heads[j]); p += 2; }
  out.set(this.ob, p);
  return out;
};
Level.prototype.hdr = function (k) { return G.u32(this.head, 0xB00 + 4 * k); };
Level.prototype.setHdr = function (k, v) { G.putU32(this.head, 0xB00 + 4 * k, v >>> 0); };
Level.prototype.vert = function (r, c) { return this.V[r * 13 + c]; };
Level.prototype.quad = function (cell) { var r = (cell / 12) | 0, c = cell % 12; return [this.vert(r, c), this.vert(r, c + 1), this.vert(r + 1, c + 1), this.vert(r + 1, c)]; };
/* Palette/Deskriptoren */
Level.prototype.palette = function () { var p = []; for (var i = 0; i < 256; i++) p.push(G.c15ToRgb(G.u16(this.head, 2 * i))); return p; };
Level.prototype.setColor = function (i, rgb) { G.putU16(this.head, 2 * i, G.rgbToC15(rgb[0], rgb[1], rgb[2])); };
Level.prototype.desc = function (k) {
  var o = 0x200 + 9 * k, h = this.head, uv = [];
  for (var p = 0; p < 4; p++) uv.push([h[o + 1 + 2 * p], h[o + 2 + 2 * p]]);
  return { k: k, type: h[o] & 15, page: h[o] >> 4, uv: uv, color: h[o + 1] };
};
Level.prototype.setDesc = function (k, d) {
  var o = 0x200 + 9 * k, h = this.head;
  h[o] = ((d.page & 15) << 4) | (d.type & 15);
  if (d.type === 1) for (var i = 0; i < 8; i++) h[o + 1 + i] = d.color & 255;
  else if (d.type === 0) for (var j = 0; j < 8; j++) h[o + 1 + j] = 0;
  else d.uv.forEach(function (q, p) { h[o + 1 + 2 * p] = q[0] & 255; h[o + 2 + 2 * p] = q[1] & 255; });
};
/* ---------------------------------------------------------------- Objekte */
Level.prototype.objects = function () {
  var out = [], seen = {}, ob = this.ob;
  for (var cell = 0; cell < this.heads.length; cell++) {
    var h = this.heads[cell], guard = 0;
    while (h >= 8 && h < ob.length && guard++ < 500) {
      if (seen[h]) break; seen[h] = 1;
      var t = G.u16(ob, h + 2);
      out.push({ off: h, cell: cell, type: t, t: t & 0x3F, cls: objClass(t), x: s16(ob, h - 8), h: s16(ob, h - 6), z: s16(ob, h - 4), lod: ob[h - 2] });
      h = s16(ob, h);
    }
  }
  return out;
};
/* Groesse eines Datensatzes (ab Vorspann) fuer verschiebbare Klassen, sonst -1 */
Level.prototype.recSize = function (o) {
  var ob = this.ob, t = G.u16(ob, o + 2) & 0x3F;
  if (t === 2) return 26;
  if (ACTOR_TYPES[t]) return ACTOR_TYPES[t];
  if (t === 1) { var nv = ob[o + 4], nf = ob[o + 5]; return 8 + 4 + 2 + 6 * nv + 10 * nf; }
  return -1;
};
Level.prototype.movable = function (o) { return this.recSize(o) > 0; };
Level.prototype.moveObj = function (o, dx, dh, dz) {
  var ob = this.ob, t = G.u16(ob, o + 2) & 0x3F;
  if (!this.movable(o)) throw new Error($t('Dieser Objekttyp kann nicht verschoben werden (Aufbau nicht vollstaendig bekannt).'));
  p16(ob, o - 8, s16(ob, o - 8) + dx); p16(ob, o - 6, s16(ob, o - 6) + dh); p16(ob, o - 4, s16(ob, o - 4) + dz);
  if (t === 1) {
    var nv = ob[o + 4];
    for (var i = 0; i < nv; i++) { var q = o + 6 + 6 * i; p16(ob, q, s16(ob, q) + dx); p16(ob, q + 2, s16(ob, q + 2) + dh); p16(ob, q + 4, s16(ob, q + 4) + dz); }
  } else {
    p16(ob, o + 4, s16(ob, o + 4) + dx); p16(ob, o + 6, s16(ob, o + 6) + dh); p16(ob, o + 8, s16(ob, o + 8) + dz);
  }
  this.relink(o);
};
Level.prototype.unlink = function (o) {
  for (var cell = 0; cell < this.heads.length; cell++) {
    var h = this.heads[cell];
    if (h === o) { this.heads[cell] = s16(this.ob, o); return cell; }
    var guard = 0;
    while (h >= 8 && guard++ < 500) {
      var n = s16(this.ob, h);
      if (n === o) { p16(this.ob, h, s16(this.ob, o)); return cell; }
      h = n;
    }
  }
  return -1;
};
Level.prototype.linkTo = function (o, cell) { p16(this.ob, o, this.heads[cell]); this.heads[cell] = o; };
Level.prototype.cellAt = function (x, z) {
  for (var cell = 0; cell < this.N * 12; cell++) if (inPoly(x, z, this.quad(cell))) return cell;
  return -1;
};
Level.prototype.relink = function (o) {
  var x = s16(this.ob, o - 8), z = s16(this.ob, o - 4), cell = this.cellAt(x, z);
  if (cell < 0) return;
  var old = this.unlink(o);
  this.linkTo(o, cell < 0 ? old : cell);
};
Level.prototype.deleteObj = function (o) { return this.unlink(o) >= 0; };
Level.prototype.duplicate = function (o, dx, dz) {
  var sz = this.recSize(o); if (sz < 0) throw new Error($t('Dieser Objekttyp kann nicht kopiert werden.'));
  var start = o - 8, rec = this.ob.slice(start, start + sz), nb = new Uint8Array(this.ob.length + sz);
  nb.set(this.ob); nb.set(rec, this.ob.length);
  var no = this.ob.length + 8;
  if (no + sz > 0x7FFF) throw new Error($t('Objektbereich voll (max. 32 KB).'));
  this.ob = nb;
  p16(this.ob, no, -1);
  var cell = this.cellAt(s16(this.ob, no - 8), s16(this.ob, no - 4)); if (cell < 0) cell = 0;
  this.linkTo(no, cell);
  this.moveObj(no, dx, 0, dz);
  return no;
};
function inPoly(x, y, pts) {
  var inside = false;
  for (var i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    var xi = pts[i].x, yi = pts[i].z, xj = pts[j].x, yj = pts[j].z;
    if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi + 1e-9) + xi)) inside = !inside;
  }
  return inside;
}
G.lvlInPoly = inPoly;

/* ---------------------------------------------------------------- Laden / Schreiben */
G.LevelModel = Level;
G.levelOpen = function (L) { return new Level(L, G.vcDecode(G.App.rom.data, L.map).data); };
G.levelWrite = function (L, bytes, label) {
  if (bytes.length > G.K.LEVEL_MAX) throw new Error($t('Level zu gross (') + bytes.length + $t(' Byte, maximal ') + G.K.LEVEL_MAX + $t(' - mehr passt nicht in den Arbeitsspeicher).'));
  if (bytes.length & 1) { var b2 = new Uint8Array(bytes.length + 1); b2.set(bytes); bytes = b2; }
  var d = G.App.rom.data, old = G.vcDecode(d, L.map);
  if (G.bytesEqual(old.data, bytes)) return { same: true };
  var encd = G.vcEncode(bytes);
  var res = G.replaceBlob(L.map, old.used, encd, { refs: G.findRefs(L.map) });
  G.logChange(label + ': ' + bytes.length + $t(' Byte, gepackt ') + encd.length + (res.moved ? $t(', verschoben nach ') + G.hx(res.off) : ''));
  G.invalidate();
  return res;
};
/* Komplett-Paket: entpackte Leveldateien */
G.levelsExportAll = function (zip) {
  var done = {}, n = 0;
  G.levels().forEach(function (L) {
    if (done[L.map]) return; done[L.map] = 1;
    zip.add('level/level' + (L.idx < 10 ? '0' : '') + L.idx + '_' + G.hex(L.map, 6) + '.bin', G.vcDecode(G.App.rom.data, L.map).data); n++;
  });
  return n;
};
G.levelsImportFile = function (name, bytes, report) {
  var m = /level\/level(\d+)_[0-9A-F]{6}\.bin$/i.exec(name); if (!m) return false;
  var L = G.levels()[+m[1]]; if (!L) { report.skip.push(name + $t(': unbekannt')); return true; }
  try { new Level(L, bytes); var r = G.levelWrite(L, bytes, L.name + $t(' (Paket)')); if (!r.same) report.done.push(L.name); }
  catch (e) { report.skip.push(name + ': ' + e.message); }
  return true;
};
})(window);
