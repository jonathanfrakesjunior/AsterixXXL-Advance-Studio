/* Asterix XXL Advance Studio - tab_level.js : Level-Editor (Draufsicht aus den 3D-Daten)
   Werkzeuge: Ansicht, Boden bemalen (Deskriptor/Flags), Gelaende heben/senken, Punkte verschieben,
   Objekte (verschieben, kopieren, loeschen), Startpunkt. Aenderungen sammeln sich in einer Arbeitskopie
   und werden mit "In ROM schreiben" VC-gepackt zurueckgeschrieben. */
(function (global) {
'use strict';
var G = global.AXS, el = G.el;
var st = { level: 0, tool: 'view', zoom: 0, cx: 0, cz: 0, tex: true, grid: true, objs: true, heights: false,
  paintDesc: 3, paintFlags: 0, paintWhat: 'desc', raise: 8, radius: 150, selCell: -1, selObj: -1, selVert: -1, descSel: 3, side: 'werkzeug' };
var W = null;          /* Arbeitskopie {lv, dirty, undo[]} */
var view = null;

function cur() {
  var L = G.levels()[st.level];
  if (!W || W.idx !== st.level) { W = { idx: st.level, L: L, lv: G.levelOpen(L), dirty: false, undo: [] }; st.zoom = 0; st.selCell = st.selObj = st.selVert = -1; }
  W.L = L;
  return W;
}
function snapshot() { W.undo.push(W.lv.serialize()); if (W.undo.length > 40) W.undo.shift(); W.dirty = true; }
function undo() { if (!W || !W.undo.length) return; W.lv.load(W.undo.pop()); W.dirty = W.undo.length > 0 || W.dirty; atlas = null; redraw(); renderSide(); }

/* ---------------------------------------------------------------- Atlas / Farben */
var atlas = null;
function getAtlas() {
  var lv = W.lv, key = W.L.tex + '_' + st.level;
  if (atlas && atlas.key === key && atlas.palStamp === palStamp()) return atlas;
  var P = lv.palette(), raw = G.vcDecode(G.App.rom.data, W.L.tex).data, h = raw.length >> 8;
  var cv = G.idxCanvas(raw, 256, h, P, false);
  atlas = { key: key, cv: cv, raw: raw, h: h, P: P, palStamp: palStamp(), cols: {} };
  return atlas;
}
function palStamp() { var s = 0, h = W.lv.head; for (var i = 0; i < 0x200; i++) s = (s * 31 + h[i]) | 0; return s; }
function descColor(k) {
  var A = getAtlas(); if (A.cols[k]) return A.cols[k];
  var d = W.lv.desc(k), c;
  if (d.type === 0) c = null;
  else if (d.type === 1) c = A.P[d.color];
  else {
    var us = d.uv.map(function (q) { return q[0]; }), vs = d.uv.map(function (q) { return q[1] + d.page * 256; }), r = 0, g = 0, b = 0, n = 0;
    for (var y = Math.min.apply(null, vs); y <= Math.max.apply(null, vs); y += 2) for (var x = Math.min.apply(null, us); x <= Math.max.apply(null, us); x += 2) {
      if (y >= A.h) continue; var p = A.P[A.raw[y * 256 + x]]; r += p[0]; g += p[1]; b += p[2]; n++;
    }
    c = n ? [r / n | 0, g / n | 0, b / n | 0] : [128, 128, 128];
  }
  A.cols[k] = c; return c;
}

/* ---------------------------------------------------------------- Ansicht */
function fit() {
  var lv = W.lv, x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
  lv.V.forEach(function (v) { x0 = Math.min(x0, v.x); x1 = Math.max(x1, v.x); z0 = Math.min(z0, v.z); z1 = Math.max(z1, v.z); });
  st.cx = (x0 + x1) / 2; st.cz = (z0 + z1) / 2;
  st.zoom = Math.min(view.w / (x1 - x0 + 200), view.h / (z1 - z0 + 200));
}
function w2s(x, z) { return [(x - st.cx) * st.zoom + view.w / 2, (st.cz - z) * st.zoom + view.h / 2]; }
function s2w(sx, sy) { return [(sx - view.w / 2) / st.zoom + st.cx, st.cz - (sy - view.h / 2) / st.zoom]; }

function drawTexTri(cx, img, s, t) {
  /* Dreieck s (Bild) mit Texturpunkten t (Atlas) affin abbilden */
  var x0 = s[0][0], y0 = s[0][1], x1 = s[1][0], y1 = s[1][1], x2 = s[2][0], y2 = s[2][1];
  var u0 = t[0][0], v0 = t[0][1], u1 = t[1][0], v1 = t[1][1], u2 = t[2][0], v2 = t[2][1];
  var den = (u1 - u0) * (v2 - v0) - (u2 - u0) * (v1 - v0);
  if (Math.abs(den) < 1e-6) return false;
  var a = ((x1 - x0) * (v2 - v0) - (x2 - x0) * (v1 - v0)) / den, b = ((x2 - x0) * (u1 - u0) - (x1 - x0) * (u2 - u0)) / den;
  var c = ((y1 - y0) * (v2 - v0) - (y2 - y0) * (v1 - v0)) / den, d = ((y2 - y0) * (u1 - u0) - (y1 - y0) * (u2 - u0)) / den;
  var e = x0 - a * u0 - b * v0, f = y0 - c * u0 - d * v0;
  cx.save(); cx.beginPath(); cx.moveTo(x0, y0); cx.lineTo(x1, y1); cx.lineTo(x2, y2); cx.closePath(); cx.clip();
  cx.setTransform(a, c, b, d, e, f); cx.drawImage(img, 0, 0); cx.restore();
  return true;
}
var OBJ_COLORS = { bill: '#3ecf5a', actor: '#ffd23f', coll: '#8a8f99', mesh: '#4da3ff', path: '#ff6b6b', special: '#c77dff' };
function redraw() {
  if (!view || !W) return;
  var cv = view.cv, cx = cv.getContext('2d'), lv = W.lv, A = getAtlas();
  cx.setTransform(1, 0, 0, 1, 0, 0); cx.fillStyle = '#0d1016'; cx.fillRect(0, 0, view.w, view.h);
  cx.imageSmoothingEnabled = false;
  var hmin = 1e9, hmax = -1e9; if (st.heights) lv.V.forEach(function (v) { hmin = Math.min(hmin, v.h); hmax = Math.max(hmax, v.h); });
  for (var cell = 0; cell < lv.N * 12; cell++) {
    var q = lv.quad(cell), val = lv.C[cell], k = val & 255, d = lv.desc(k);
    var s = q.map(function (v) { return w2s(v.x, v.z); });
    if (st.heights) {
      var hv = (q[0].h + q[1].h + q[2].h + q[3].h) / 4, tt = (hv - hmin) / Math.max(1, hmax - hmin);
      cx.fillStyle = 'rgb(' + (40 + 200 * tt | 0) + ',' + (60 + 150 * tt | 0) + ',' + (120 - 60 * tt | 0) + ')';
      cx.beginPath(); s.forEach(function (p, i) { if (i) cx.lineTo(p[0], p[1]); else cx.moveTo(p[0], p[1]); }); cx.closePath(); cx.fill();
    } else if (st.tex && d.type === 3) {
      var uv = d.uv.map(function (p) { return [p[0] + 0.5, p[1] + d.page * 256 + 0.5]; });
      drawTexTri(cx, A.cv, [s[0], s[1], s[2]], [uv[0], uv[1], uv[2]]);
      drawTexTri(cx, A.cv, [s[0], s[2], s[3]], [uv[0], uv[2], uv[3]]);
    } else {
      var c = descColor(k); if (!c) { cx.fillStyle = 'rgba(80,80,90,.25)'; } else cx.fillStyle = 'rgb(' + c.join(',') + ')';
      cx.beginPath(); s.forEach(function (p, i) { if (i) cx.lineTo(p[0], p[1]); else cx.moveTo(p[0], p[1]); }); cx.closePath(); cx.fill();
    }
    if (st.grid && st.zoom > 0.08) {
      cx.strokeStyle = 'rgba(0,0,0,.35)'; cx.lineWidth = 1; cx.beginPath(); s.forEach(function (p, i) { if (i) cx.lineTo(p[0], p[1]); else cx.moveTo(p[0], p[1]); }); cx.closePath(); cx.stroke();
    }
    if (st.showFlag !== undefined && st.showFlag >= 0 && (val >> (8 + st.showFlag)) & 1) {
      cx.fillStyle = 'rgba(255,40,40,.45)'; cx.beginPath(); s.forEach(function (p, i) { if (i) cx.lineTo(p[0], p[1]); else cx.moveTo(p[0], p[1]); }); cx.closePath(); cx.fill();
    }
  }
  /* Auswahl */
  if (st.selCell >= 0) {
    var sq = lv.quad(st.selCell).map(function (v) { return w2s(v.x, v.z); });
    cx.strokeStyle = '#fff'; cx.lineWidth = 2; cx.beginPath(); sq.forEach(function (p, i) { if (i) cx.lineTo(p[0], p[1]); else cx.moveTo(p[0], p[1]); }); cx.closePath(); cx.stroke();
  }
  if (st.tool === 'verts' || st.tool === 'height') {
    cx.fillStyle = 'rgba(255,255,255,.7)';
    lv.V.forEach(function (v, i) { var p = w2s(v.x, v.z); cx.fillRect(p[0] - 1.5, p[1] - 1.5, 3, 3); });
    if (st.selVert >= 0) { var sv = lv.V[st.selVert], pp = w2s(sv.x, sv.z); cx.strokeStyle = '#ff0'; cx.strokeRect(pp[0] - 5, pp[1] - 5, 10, 10); }
  }
  /* Objekte */
  if (st.objs) {
    lv.objects().forEach(function (o) {
      var p = w2s(o.x, o.z), r = o.off === st.selObj ? 6 : 3.5;
      cx.fillStyle = OBJ_COLORS[o.cls] || '#fff'; cx.strokeStyle = '#000'; cx.lineWidth = 1;
      cx.beginPath(); cx.arc(p[0], p[1], r, 0, 7); cx.fill(); cx.stroke();
      if (o.off === st.selObj) { cx.strokeStyle = '#fff'; cx.lineWidth = 2; cx.beginPath(); cx.arc(p[0], p[1], r + 3, 0, 7); cx.stroke(); }
    });
  }
  /* Startpunkt */
  var sc = lv.hdr(1);
  if (sc < lv.N * 12) {
    var sq2 = lv.quad(sc), mx = 0, mz = 0; sq2.forEach(function (v) { mx += v.x / 4; mz += v.z / 4; });
    var sp = w2s(mx, mz);
    cx.fillStyle = '#ff2d2d'; cx.strokeStyle = '#fff'; cx.lineWidth = 2;
    cx.beginPath(); cx.moveTo(sp[0], sp[1] - 12); cx.lineTo(sp[0] + 8, sp[1] + 6); cx.lineTo(sp[0] - 8, sp[1] + 6); cx.closePath(); cx.fill(); cx.stroke();
  }
  cx.setTransform(1, 0, 0, 1, 0, 0);
  cx.fillStyle = 'rgba(0,0,0,.6)'; cx.fillRect(0, view.h - 22, view.w, 22); cx.fillStyle = '#cfd6e4'; cx.font = '12px Segoe UI';
  cx.fillText(W.L.name + '  |  N=' + lv.N + $t(' Abschnitte')  + '  |  Zoom ' + st.zoom.toFixed(3) + (W.dirty ? $t('  |  ungespeicherte Aenderungen') : ''), 8, view.h - 7);
}

/* ---------------------------------------------------------------- Maus */
function nearestVert(x, z, maxPx) {
  var lv = W.lv, best = -1, bd = (maxPx / st.zoom) * (maxPx / st.zoom);
  lv.V.forEach(function (v, i) { var dx = v.x - x, dz = v.z - z, dd = dx * dx + dz * dz; if (dd < bd) { bd = dd; best = i; } });
  return best;
}
function nearestObj(x, z) {
  var best = -1, bd = (9 / st.zoom) * (9 / st.zoom);
  W.lv.objects().forEach(function (o) { var dx = o.x - x, dz = o.z - z, dd = dx * dx + dz * dz; if (dd < bd) { bd = dd; best = o.off; } });
  return best;
}
function paintCell(cell) {
  var v = W.lv.C[cell], nv = v;
  if (st.paintWhat === 'desc' || st.paintWhat === 'both') nv = (nv & 0xFF00) | (st.paintDesc & 255);
  if (st.paintWhat === 'flags' || st.paintWhat === 'both') nv = (nv & 0xFF) | ((st.paintFlags & 255) << 8);
  if (nv !== v) { W.lv.C[cell] = nv; return true; }
  return false;
}
function raiseAt(x, z, dir) {
  var lv = W.lv, n = 0;
  lv.V.forEach(function (v) {
    var d = Math.sqrt((v.x - x) * (v.x - x) + (v.z - z) * (v.z - z));
    if (d > st.radius) return;
    var f = st.radius > 0 ? 0.5 + 0.5 * Math.cos(Math.PI * d / st.radius) : 1;
    v.h = Math.max(-32000, Math.min(32000, Math.round(v.h + dir * st.raise * f))); n++;
  });
  return n;
}
function attachMouse(cv) {
  var drag = null;
  cv.oncontextmenu = function (e) { e.preventDefault(); };
  cv.onwheel = function (e) {
    e.preventDefault();
    var r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top, before = s2w(mx, my);
    st.zoom *= e.deltaY < 0 ? 1.2 : 1 / 1.2; st.zoom = Math.max(0.01, Math.min(8, st.zoom));
    var after = s2w(mx, my); st.cx += before[0] - after[0]; st.cz += before[1] - after[1]; redraw();
  };
  cv.onmousedown = function (e) {
    var r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top, w = s2w(mx, my), lv = W.lv;
    if (e.button === 1 || e.button === 2 && st.tool !== 'height' || st.tool === 'view') { drag = { mode: 'pan', x: mx, y: my, cx: st.cx, cz: st.cz, click: true }; return; }
    if (st.tool === 'paint' || st.tool === 'start') {
      var cell = lv.cellAt(w[0], w[1]); if (cell < 0) return;
      if (st.tool === 'start') { snapshot(); lv.setHdr(1, cell); G.toast($t('Startpunkt gesetzt (Zelle ') + cell + ')'); st.selCell = cell; redraw(); renderSide(); return; }
      if (e.altKey) { st.paintDesc = lv.C[cell] & 255; st.paintFlags = lv.C[cell] >> 8; st.selCell = cell; renderSide(); redraw(); return; }
      snapshot(); paintCell(cell); st.selCell = cell; drag = { mode: 'paint' }; redraw(); renderSide(); return;
    }
    if (st.tool === 'height') { snapshot(); raiseAt(w[0], w[1], e.button === 2 || e.shiftKey ? -1 : 1); drag = { mode: 'height', dir: e.button === 2 || e.shiftKey ? -1 : 1, t: Date.now() }; redraw(); return; }
    if (st.tool === 'verts') {
      var vi = nearestVert(w[0], w[1], 10); st.selVert = vi; renderSide();
      if (vi >= 0) { snapshot(); drag = { mode: 'vert', vi: vi }; }
      redraw(); return;
    }
    if (st.tool === 'objs') {
      var o = nearestObj(w[0], w[1]); st.selObj = o; renderSide(); redraw();
      if (o >= 0) {
        var ob = lv.objects().filter(function (x) { return x.off === o; })[0];
        if (lv.movable(o)) drag = { mode: 'obj', o: o, sx: w[0], sz: w[1], ox: ob.x, oz: ob.z, moved: false };
      } else drag = { mode: 'pan', x: mx, y: my, cx: st.cx, cz: st.cz };
    }
  };
  window.onmousemove = function (e) {
    if (!drag || !view) return;
    var r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top, w = s2w(mx, my), lv = W.lv;
    if (drag.mode === 'pan') { st.cx = drag.cx - (mx - drag.x) / st.zoom; st.cz = drag.cz + (my - drag.y) / st.zoom; redraw(); }
    else if (drag.mode === 'paint') { var cell = lv.cellAt(w[0], w[1]); if (cell >= 0 && paintCell(cell)) redraw(); }
    else if (drag.mode === 'height') { if (Date.now() - drag.t > 60) { raiseAt(w[0], w[1], drag.dir); drag.t = Date.now(); redraw(); } }
    else if (drag.mode === 'vert') { var v = lv.V[drag.vi]; v.x = Math.round(w[0]); v.z = Math.round(w[1]); redraw(); }
    else if (drag.mode === 'obj') {
      if (!drag.moved) { snapshot(); drag.moved = true; }
      var ob = lv.objects().filter(function (x) { return x.off === drag.o; })[0]; if (!ob) return;
      var tx = Math.round(drag.ox + w[0] - drag.sx), tz = Math.round(drag.oz + w[1] - drag.sz);
      try { lv.moveObj(drag.o, tx - ob.x, 0, tz - ob.z); } catch (er) { drag = null; G.toast(er.message, 'err'); }
      redraw();
    }
  };
  window.onmouseup = function () { if (drag && drag.mode !== 'pan') renderSide(); drag = null; };
}

/* ---------------------------------------------------------------- Seitenleiste */
var sideEl = null;
function renderSide() {
  if (!sideEl || !W) return;
  var s = G.clear(sideEl), lv = W.lv;
  var tabs = el('div', { class: 'row tight' });
  [['werkzeug', $t('Werkzeug')], ['deskriptoren', $t('Texturen')], ['palette', $t('Palette')], ['level', $t('Level')]].forEach(function (x) {
    tabs.appendChild(G.button(x[1], function () { st.side = x[0]; renderSide(); }, st.side === x[0] ? 'on' : ''));
  });
  s.appendChild(tabs);
  if (st.side === 'werkzeug') sideTool(s, lv);
  else if (st.side === 'deskriptoren') sideDesc(s, lv);
  else if (st.side === 'palette') sidePal(s, lv);
  else sideLevel(s, lv);
}
function descSwatch(k, size) {
  var lv = W.lv, d = lv.desc(k), A = getAtlas(), c = el('canvas', { width: size, height: size, title: $t('Deskriptor ') + k });
  var cx = c.getContext('2d'); cx.imageSmoothingEnabled = false;
  if (d.type === 3) {
    var uv = d.uv.map(function (p) { return [p[0] + 0.5, p[1] + d.page * 256 + 0.5]; });
    drawTexTri(cx, A.cv, [[0, 0], [size, 0], [size, size]], [uv[0], uv[1], uv[2]]);
    drawTexTri(cx, A.cv, [[0, 0], [size, size], [0, size]], [uv[0], uv[2], uv[3]]);
  } else if (d.type === 1) { cx.fillStyle = 'rgb(' + A.P[d.color].join(',') + ')'; cx.fillRect(0, 0, size, size); }
  else { cx.fillStyle = '#222'; cx.fillRect(0, 0, size, size); cx.strokeStyle = '#a33'; cx.beginPath(); cx.moveTo(0, 0); cx.lineTo(size, size); cx.stroke(); }
  return c;
}
function flagBoxes(value, onchange) {
  var names = [$t('Bit 0 (begehbar/Boden)'), $t('Bit 1 (Hauptweg)'), $t('Bit 2 (Uferkante)'), $t('Bit 3'), $t('Bit 4'), $t('Bit 5'), $t('Bit 6 (spaeter zeichnen)'), $t('Bit 7')];
  var box = el('div', { class: 'flaggrid' });
  names.forEach(function (n, b) {
    box.appendChild(el('label', { class: 'chk', style: { display: 'flex' } }, [el('input', { type: 'checkbox', checked: (value >> b) & 1, onchange: function () { onchange(this.checked ? value | (1 << b) : value & ~(1 << b)); } }), n]));
  });
  return box;
}
function sideTool(s, lv) {
  var tools = [['view', $t('Ansehen')], ['paint', $t('Boden bemalen')], ['height', $t('Gelaende')], ['verts', $t('Punkte')], ['objs', $t('Objekte')], ['start', $t('Startpunkt')]];
  var tb = el('div', { class: 'row tight', style: { marginTop: '8px' } });
  tools.forEach(function (t) { tb.appendChild(G.button(t[1], function () { st.tool = t[0]; renderSide(); redraw(); }, st.tool === t[0] ? 'on' : '')); });
  s.appendChild(tb);
  var help = {
    view: $t('Ziehen = verschieben, Mausrad = Zoom. Rechte/mittlere Maustaste verschiebt in jedem Werkzeug.'),
    paint: $t('Klicken/Ziehen malt die gewaehlte Textur bzw. Flags auf die Bodenvierecke. Alt+Klick uebernimmt Textur und Flags einer Zelle.'),
    height: $t('Linksklick hebt, Rechtsklick oder Umschalt+Klick senkt das Gelaende weich im Radius. Gedrueckt halten wirkt weiter.'),
    verts: $t('Punkt anklicken und ziehen, um die Bodenform zu aendern. Hoehe unten eintragen.'),
    objs: $t('Objekt anklicken; verschiebbare Objekte lassen sich ziehen. Farben: gruen Pflanzen, gelb Figuren/Gegenstaende, blau 3D-Objekte, grau Kollision, rot Pfade.'),
    start: $t('Zelle anklicken = Startpunkt von Asterix/Obelix.')
  };
  s.appendChild(el('p', { class: 'hint', text: help[st.tool] }));
  if (st.tool === 'paint') {
    s.appendChild(el('div', { class: 'row tight' }, [el('span', { class: 'mut', text: $t('Malt') }),
      G.select([{ value: 'desc', label: $t('Textur') }, { value: 'flags', label: $t('Flags') }, { value: 'both', label: $t('Textur + Flags') }], st.paintWhat, function (x) { st.paintWhat = x; })]));
    s.appendChild(el('div', { class: 'row tight', style: { marginTop: '6px' } }, [descSwatch(st.paintDesc, 40), el('span', { text: $t('Textur ') + st.paintDesc }),
      G.button($t('Waehlen'), function () { st.side = 'deskriptoren'; st.descSel = st.paintDesc; renderSide(); })]));
    s.appendChild(el('h4', { text: $t('Flags'), style: { marginTop: '10px' } }));
    s.appendChild(flagBoxes(st.paintFlags, function (v) { st.paintFlags = v; renderSide(); }));
  }
  if (st.tool === 'height') {
    s.appendChild(el('div', { class: 'fieldgrid' }, [
      el('label', {}, [$t('Staerke'), el('input', { type: 'number', value: st.raise, min: 1, max: 200, onchange: function () { st.raise = +this.value; } })]),
      el('label', {}, [$t('Radius'), el('input', { type: 'number', value: st.radius, min: 10, max: 3000, onchange: function () { st.radius = +this.value; } })])]));
  }
  if (st.tool === 'verts' && st.selVert >= 0) {
    var v = lv.V[st.selVert], r = (st.selVert / 13) | 0, c = st.selVert % 13;
    s.appendChild(el('h4', { text: $t('Punkt ') + r + '/' + c, style: { marginTop: '10px' } }));
    var ix = el('input', { type: 'number', value: v.x }), ih = el('input', { type: 'number', value: v.h }), iz = el('input', { type: 'number', value: v.z });
    s.appendChild(el('div', { class: 'fieldgrid' }, [el('label', {}, ['X', ix]), el('label', {}, [$t('Hoehe'), ih]), el('label', {}, ['Z', iz])]));
    s.appendChild(G.button($t('Setzen'), function () { snapshot(); v.x = +ix.value; v.h = +ih.value; v.z = +iz.value; redraw(); }));
  }
  if ((st.tool === 'paint' || st.tool === 'view' || st.tool === 'start') && st.selCell >= 0) {
    var val = lv.C[st.selCell];
    s.appendChild(el('div', { class: 'card', style: { marginTop: '10px' } }, [el('h4', { text: $t('Zelle ') + st.selCell + $t(' (Abschnitt ') + ((st.selCell / 12) | 0) + $t(', Spalte ') + (st.selCell % 12) + ')' }),
      el('div', { class: 'row tight' }, [descSwatch(val & 255, 32), el('span', { class: 'mono', text: $t('Textur ') + (val & 255) + $t(', Flags 0x') + G.hex(val >> 8, 2) })])]));
  }
  if (st.tool === 'objs') sideObj(s, lv);
  s.appendChild(el('h4', { text: $t('Anzeige'), style: { marginTop: '12px' } }));
  [['tex', $t('Texturen')], ['grid', $t('Raster')], ['objs', $t('Objekte')], ['heights', $t('Hoehen einfaerben')]].forEach(function (x) {
    s.appendChild(el('label', { class: 'chk', style: { display: 'flex' } }, [el('input', { type: 'checkbox', checked: st[x[0]], onchange: function () { st[x[0]] = this.checked; redraw(); } }), x[1]]));
  });
  s.appendChild(el('div', { class: 'row tight' }, [el('span', { class: 'mut', text: $t('Flag hervorheben') }),
    G.select([{ value: -1, label: '-' }].concat([0, 1, 2, 3, 4, 5, 6, 7].map(function (b) { return { value: b, label: 'Bit ' + b }; })), st.showFlag === undefined ? -1 : st.showFlag, function (x) { st.showFlag = +x; redraw(); })]));
}
function sideObj(s, lv) {
  var objs = lv.objects(), o = objs.filter(function (x) { return x.off === st.selObj; })[0];
  var counts = {}; objs.forEach(function (x) { counts[x.cls] = (counts[x.cls] || 0) + 1; });
  s.appendChild(el('div', { class: 'hint', text: objs.length + $t(' Objekte: ') + Object.keys(counts).map(function (k) { return G.lvlClassNames[k] + ' ' + counts[k]; }).join(', ') }));
  if (!o) return;
  var mov = lv.movable(o.off);
  s.appendChild(el('div', { class: 'card', style: { marginTop: '8px' } }, [
    el('h4', { text: G.lvlClassNames[o.cls] + $t(' - Typ ') + o.t }),
    el('div', { class: 'kv' }, [el('b', { text: $t('Offset') }), el('span', { class: 'mono', text: G.hx(o.off, 4) }), el('b', { text: $t('Typwert') }), el('span', { class: 'mono', text: G.hx(o.type, 4) }),
      el('b', { text: $t('Position') }), el('span', { text: o.x + ' / ' + o.h + ' / ' + o.z }), el('b', { text: $t('Sichtweite') }), el('span', { text: o.lod ? String(o.lod) : $t('immer') }),
      el('b', { text: $t('Zelle') }), el('span', { text: String(o.cell) })]),
    mov ? el('div', { class: 'row tight', style: { marginTop: '8px' } }, [
      el('span', { class: 'mut', text: $t('Hoehe') }),
      G.button('-16', function () { snapshot(); lv.moveObj(o.off, 0, -16, 0); redraw(); renderSide(); }),
      G.button('+16', function () { snapshot(); lv.moveObj(o.off, 0, 16, 0); redraw(); renderSide(); }),
      G.button($t('Kopieren'), function () { try { snapshot(); st.selObj = lv.duplicate(o.off, 96, 0); G.toast($t('Kopie angelegt (rechts daneben).')); redraw(); renderSide(); } catch (e) { G.toast(e.message, 'err'); } })
    ]) : el('p', { class: 'hint', text: $t('Dieser Typ ist fest (Aufbau nur teilweise bekannt) - loeschen geht, verschieben nicht.') }),
    el('div', { class: 'row tight', style: { marginTop: '6px' } }, [G.button($t('Loeschen'), function () { snapshot(); lv.deleteObj(o.off); st.selObj = -1; redraw(); renderSide(); }, 'danger')])
  ]));
}
function sideDesc(s, lv) {
  var d = lv.desc(st.descSel), A = getAtlas();
  var grid = el('div', { class: 'descgrid', style: { display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: '2px', maxHeight: '240px', overflow: 'auto', marginTop: '8px' } });
  for (var k = 0; k < 256; k++) (function (k) {
    var c = descSwatch(k, 26); c.style.cursor = 'pointer'; c.style.outline = k === st.descSel ? '2px solid #fff' : (k === st.paintDesc ? '2px solid var(--acc)' : 'none');
    c.onclick = function () { st.descSel = k; renderSide(); };
    grid.appendChild(c);
  })(k);
  s.appendChild(grid);
  s.appendChild(el('div', { class: 'row tight', style: { marginTop: '8px' } }, [descSwatch(st.descSel, 64), el('div', {}, [el('b', { text: $t('Textur ') + st.descSel }),
    el('div', {}, [G.button($t('Zum Malen verwenden'), function () { st.paintDesc = st.descSel; st.tool = 'paint'; st.side = 'werkzeug'; renderSide(); redraw(); }, 'primary')])])]));
  var type = G.select([{ value: 0, label: $t('0 unsichtbar') }, { value: 1, label: $t('1 Farbe') }, { value: 3, label: $t('3 Textur') }], d.type, function (x) { d.type = +x; });
  var page = el('input', { type: 'number', min: 0, max: 2, value: d.page }), color = el('input', { type: 'number', min: 0, max: 255, value: d.color });
  var uvs = d.uv.map(function (q) { return [el('input', { type: 'number', min: 0, max: 255, value: q[0] }), el('input', { type: 'number', min: 0, max: 255, value: q[1] })]; });
  var f = el('div', { class: 'fieldgrid' }, [el('label', {}, [$t('Typ'), type]), el('label', {}, [$t('Seite (0-2)'), page]), el('label', {}, [$t('Farbindex'), color])]);
  uvs.forEach(function (u, i) { f.appendChild(el('label', {}, [$t('Ecke ') + (i + 1) + ' u', u[0]])); f.appendChild(el('label', {}, [$t('Ecke ') + (i + 1) + ' v', u[1]])); });
  s.appendChild(f);
  s.appendChild(el('div', { class: 'row tight', style: { marginTop: '6px' } }, [
    G.button($t('Uebernehmen'), function () {
      snapshot();
      lv.setDesc(st.descSel, { type: d.type, page: +page.value, color: +color.value, uv: uvs.map(function (u) { return [+u[0].value, +u[1].value]; }) });
      atlas = null; redraw(); renderSide();
    }),
    G.button($t('Rechteck'), function () {
      var u0 = +uvs[0][0].value, v0 = +uvs[0][1].value, u1 = +uvs[2][0].value, v1 = +uvs[2][1].value;
      uvs[1][0].value = u1; uvs[1][1].value = v0; uvs[3][0].value = u0; uvs[3][1].value = v1;
    }, '', $t('Ecken 2 und 4 aus Ecke 1 (links oben) und 3 (rechts unten) ergaenzen'))]));
  s.appendChild(el('p', { class: 'hint', text: $t('Die Ecken (u,v) liegen im Welt-Atlas (256 breit); Seite 1 = Zeilen 256-511, Seite 2 = ab 512. Ecke 1-4 = Viereck-Ecken in Laufrichtung (links vorn, rechts vorn, rechts hinten, links hinten). Den Atlas bearbeitest du unter "Bilder & Texturen".') }));
  var ac = G.idxCanvas(A.raw, 256, A.h, A.P, false); ac.style.width = '256px'; ac.style.display = 'block'; ac.style.marginTop = '6px';
  var cx = ac.getContext('2d'); if (d.type === 3) { cx.strokeStyle = '#ff0'; cx.beginPath(); d.uv.forEach(function (q, i) { var y = q[1] + d.page * 256; if (i) cx.lineTo(q[0], y); else cx.moveTo(q[0], y); }); cx.closePath(); cx.stroke(); }
  s.appendChild(el('div', { style: { maxHeight: '300px', overflow: 'auto' } }, [ac]));
}
function sidePal(s, lv) {
  var P = lv.palette();
  s.appendChild(el('p', { class: 'hint', text: $t('Bodenpalette dieses Levels (256 Farben, auch fuer den Welt-Atlas). Farbe anklicken zum Aendern. Jedes Level hat eine eigene Kopie.') }));
  s.appendChild(G.palGrid(P, 0, 255, function (i) {
    var inp = el('input', { type: 'color', value: G.hexColor(P[i]), style: { position: 'fixed', left: '-100px' } });
    document.body.appendChild(inp);
    inp.onchange = function () { snapshot(); lv.setColor(i, G.parseHex(inp.value)); inp.remove(); atlas = null; redraw(); renderSide(); };
    inp.click();
  }));
  s.appendChild(el('div', { class: 'row tight', style: { marginTop: '8px' } }, [
    G.button($t('JASC .pal exportieren'), function () { G.download('level' + st.level + '_palette.pal', new TextEncoder().encode('JASC-PAL\r\n0100\r\n256\r\n' + P.map(function (c) { return c.join(' '); }).join('\r\n') + '\r\n')); }),
    G.button($t('Palette von Level kopieren ...'), async function () {
      var sel = G.select(G.levels().map(function (L, i) { return { value: i, label: L.name }; }), 0, function () { });
      if (!await G.modal($t('Palette kopieren'), sel, [{ label: $t('Abbrechen'), value: false }, { label: $t('Kopieren'), value: true, primary: true }])) return;
      var src = G.levelOpen(G.levels()[+sel.value]); snapshot(); lv.head.set(src.head.subarray(0, 0x200), 0); atlas = null; redraw(); renderSide();
    })]));
}
function sideLevel(s, lv) {
  var L = W.L, shared = G.levels().filter(function (x) { return x.map === L.map && x !== L; });
  s.appendChild(el('div', { class: 'kv', style: { marginTop: '8px' } }, [
    el('b', { text: $t('Leveldatei') }), el('span', { class: 'mono', text: G.hx(L.map) }),
    el('b', { text: $t('Texturatlas') }), el('span', { class: 'mono', text: G.hx(L.tex) }),
    el('b', { text: $t('Abschnitte') }), el('span', { text: lv.N + ' x 12 ' + $t('Zellen') }),
    el('b', { text: $t('Groesse') }), el('span', { text: lv.serialize().length + ' / ' + G.K.LEVEL_MAX + $t(' Byte') })]));
  if (shared.length) s.appendChild(el('p', { class: 'warnbox', text: $t('Diese Leveldatei wird auch benutzt von: ') + shared.map(function (x) { return x.name; }).join(', ') }));
  var tgt = el('input', { type: 'number', value: lv.hdr(3), min: 0, max: 9999 }), vr = el('input', { type: 'number', value: lv.hdr(2), min: 0, max: 3 });
  s.appendChild(el('div', { class: 'fieldgrid', style: { marginTop: '8px' } }, [el('label', {}, [$t('Zielwert fuer 100 %'), tgt]), el('label', {}, [$t('Variante'), vr])]));
  s.appendChild(G.button($t('Werte setzen'), function () { snapshot(); lv.setHdr(3, +tgt.value); lv.setHdr(2, +vr.value); G.toast($t('Gesetzt.')); }));
  s.appendChild(el('p', { class: 'hint', text: $t('Zielwert = Zahl der Sammelobjekte, die fuer "100 %" noetig ist (nach dem Loeschen oder Kopieren von Helmen anpassen). Variante waehlt eine Einstellungstabelle der Engine (0-3).') }));
  s.appendChild(el('h4', { text: $t('Rohdaten'), style: { marginTop: '10px' } }));
  s.appendChild(el('div', { class: 'row tight' }, [
    G.button($t('Leveldatei exportieren (.bin)'), function () { G.download('level' + st.level + '_' + G.hex(L.map, 6) + '.bin', lv.serialize()); }),
    G.button($t('Importieren ...'), async function () {
      var f = await G.pickFile('.bin'); if (!f) return;
      try { var b = await G.readFileBytes(f); snapshot(); lv.load(b); atlas = null; redraw(); renderSide(); G.toast($t('Geladen - mit "In ROM schreiben" uebernehmen.')); } catch (e) { G.toast(e.message, 'err'); }
    })]));
}

/* ---------------------------------------------------------------- Tab */
function commit() {
  if (!W) return;
  try {
    G.busy($t('Level wird gepackt ...'));
    setTimeout(function () {
      try {
        var r = G.levelWrite(W.L, W.lv.serialize(), W.L.name);
        G.busy(false);
        W.dirty = false; W.undo = [];
        var L = G.levels()[st.level]; W.L = L;
        G.toast(r.same ? $t('Keine Aenderungen.') : $t('Level in die ROM geschrieben.') + (r.moved ? $t(' (verschoben nach ') + G.hx(r.off) + ')' : ''));
        G.updateStatus(); redraw();
      } catch (e) { G.busy(false); G.toast(e.message, 'err'); }
    }, 30);
  } catch (e) { G.busy(false); G.toast(e.message, 'err'); }
}
async function switchLevel(i) {
  if (W && W.dirty && !await G.confirmBox($t('Ungespeicherte Aenderungen'), $t('Das aktuelle Level hat Aenderungen, die noch nicht in die ROM geschrieben wurden. Verwerfen?'), $t('Verwerfen'))) { G.refreshTab(); return; }
  st.level = i; W = null; atlas = null; G.refreshTab();
}
G.registerTab({
  id: 'level', label: $t('Level-Editor'), icon: '⛰', group: $t('Welt'), needsRom: true,
  leave: function () { window.onmousemove = null; window.onmouseup = null; view = null; },
  render: function (v) {
    var w; try { w = cur(); } catch (e) { v.appendChild(el('div', { class: 'card err', text: e.message })); return; }
    v.appendChild(el('div', { class: 'toolbar' }, [
      el('b', { text: $t('Level') }),
      G.select(G.levels().map(function (L, i) { return { value: i, label: (i + 1) + '. ' + L.name }; }), st.level, function (x) { switchLevel(+x); }),
      G.button($t('Einpassen'), function () { fit(); redraw(); }),
      G.button($t('Rueckgaengig'), undo),
      el('span', { class: 'spacer' }),
      G.button($t('Verwerfen'), async function () { if (!W.dirty || await G.confirmBox($t('Verwerfen'), $t('Alle ungespeicherten Aenderungen an diesem Level verwerfen?'), $t('Verwerfen'))) { W = null; atlas = null; G.refreshTab(); } }),
      G.button($t('In ROM schreiben'), commit, 'primary')
    ]));
    var wrap = el('div', { class: 'split', style: { alignItems: 'stretch' } });
    var cv = el('canvas', { style: { background: '#0d1016', borderRadius: '8px', cursor: 'crosshair', display: 'block' } });
    var box = el('div', { style: { flex: '1', minWidth: '0', position: 'relative' } }, [cv]);
    sideEl = el('div', { class: 'side', style: { width: '330px', overflowY: 'auto', maxHeight: 'calc(100vh - 150px)' } });
    wrap.appendChild(box); wrap.appendChild(sideEl); v.appendChild(wrap);
    setTimeout(function () {
      var wd = Math.max(400, box.clientWidth), ht = Math.max(360, window.innerHeight - 170);
      cv.width = wd; cv.height = ht; view = { cv: cv, w: wd, h: ht };
      if (!st.zoom) fit();
      attachMouse(cv); redraw(); renderSide();
    }, 0);
  }
});
G.levelEditorDirty = function () { return !!(W && W.dirty); };
/* Test-Hilfe: Level in eine eigene Leinwand zeichnen */
G.levelRenderTo = function (idx, w, h, opts) {
  st.level = idx; cur(); var old = view, cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  Object.assign(st, opts || {}); view = { cv: cv, w: w, h: h }; fit(); redraw(); view = old; return cv;
};
})(window);
