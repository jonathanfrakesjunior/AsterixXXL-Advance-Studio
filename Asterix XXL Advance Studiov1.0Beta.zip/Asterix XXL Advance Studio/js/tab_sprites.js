/* Asterix XXL Advance Studio - tab_sprites.js : Figuren-Animationen (4 Bit linear, 16 Farben, Index 0 durchsichtig) */
(function (global) {
'use strict';
var G = global.AXS, el = G.el;
var state = { kind: null, set: 0, frame: 0, pal: null, bank: null };
var SHEET_COLS = 8;

function uniqFrames(set) {
  var seen = {}, out = [];
  set.frames.forEach(function (f) { if (!seen[f.px]) { seen[f.px] = 1; out.push(f); } });
  return out;
}
/* Pixel -> Indizes 0-15 (hohes Halbbyte = linkes Pixel) */
function framePx(f) {
  var d = G.App.rom.data, bpr = (f.w + 1) >> 1, out = new Uint8Array(f.w * f.h);
  for (var y = 0; y < f.h; y++) for (var x = 0; x < f.w; x++) {
    var b = d[f.px + y * bpr + (x >> 1)];
    out[y * f.w + x] = (x & 1) ? (b & 15) : (b >> 4);
  }
  return out;
}
function encodePx(idx, w, h) {
  var bpr = (w + 1) >> 1, out = new Uint8Array(bpr * h);
  for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
    var v = idx[y * w + x] & 15, o = y * bpr + (x >> 1);
    out[o] |= (x & 1) ? v : (v << 4);
  }
  return out;
}
function palOptions() {
  var o = [{ value: G.K.HERO_PAL, label: $t('Asterix & Obelix') }, { value: G.K.HERO_PAL + 0x46, label: $t('Asterix & Obelix (Variante)') }];
  G.worlds().forEach(function (w) { o.push({ value: w.objPal, label: $t('Welt ') + w.name }); });
  return o;
}
function setDefaults(set) {
  state.pal = set.pal === -2 ? G.worlds()[0].objPal : set.pal;
  state.bank = set.bank;
}
function curPal() {
  var full = G.composePal([G.K.HERO_PAL, state.pal]).obj, p = [];
  for (var i = 0; i < 16; i++) p.push(full[state.bank * 16 + i] || [255, 0, 255]);
  return p;
}

function sheetOf(frames) {
  var cw = 0, ch = 0;
  frames.forEach(function (f) { cw = Math.max(cw, f.w); ch = Math.max(ch, f.h); });
  var cols = Math.min(SHEET_COLS, frames.length), rows = Math.ceil(frames.length / cols), W = cols * cw, H = rows * ch, idx = new Uint8Array(W * H);
  frames.forEach(function (f, k) {
    var x0 = (k % cols) * cw, y0 = ((k / cols) | 0) * ch, px = framePx(f);
    for (var y = 0; y < f.h; y++) idx.set(px.subarray(y * f.w, y * f.w + f.w), (y0 + y) * W + x0);
  });
  return { idx: idx, w: W, h: H, cw: cw, ch: ch, cols: cols };
}
function writeFrame(f, idx, label) {
  var d = G.App.rom.data, enc = encodePx(idx, f.w, f.h), old = d.subarray(f.px, f.px + enc.length);
  if (G.bytesEqual(old, enc)) return false;
  d.set(enc, f.px);
  G.logChange(label || ($t('Sprite ') + G.hx(f.px) + ' ' + f.w + 'x' + f.h));
  return true;
}
/* Einzelbild mit neuer Groesse: Pixel ans ROM-Ende, alle Eintraege mit denselben Daten anpassen */
function resizeFrame(f, w, h, idx) {
  var r = G.App.rom, enc = encodePx(idx, w, h), al = new G.Allocator(r, true), at = al.alloc(enc.length);
  if (at < 0) throw new Error($t('Kein Platz in der ROM.'));
  r.data.set(enc, at);
  var d = r.data, oldPx = f.px, n = 0;
  G.cached('sprites', G.spriteCatalog).forEach(function (s) {
    s.frames.forEach(function (fr) {
      if (fr.px !== oldPx) return;
      var ox = Math.round(fr.ox * w / fr.w), oy = Math.round(fr.oy * h / fr.h);
      d[fr.at] = ox & 255; d[fr.at + 1] = oy & 255; d[fr.at + 2] = w; d[fr.at + 3] = h;
      G.putU32(d, fr.at + 4, 0x08000000 + at); n++;
    });
  });
  G.logChange($t('Sprite ') + G.hx(oldPx) + $t(' neue Groesse ') + w + 'x' + h + ' (' + n + $t(' Eintraege, Daten bei ') + G.hx(at) + ')');
  G.invalidate(['sprites']);
}
function sheetImport(frames, sh, idx, W) {
  var n = 0;
  frames.forEach(function (f, k) {
    var x0 = (k % sh.cols) * sh.cw, y0 = ((k / sh.cols) | 0) * sh.ch, sub = new Uint8Array(f.w * f.h);
    for (var y = 0; y < f.h; y++) sub.set(idx.subarray((y0 + y) * W + x0, (y0 + y) * W + x0 + f.w), y * f.w);
    if (writeFrame(f, sub, $t('Sprite ') + G.hx(f.px))) n++;
  });
  return n;
}
function to16(idx) { return idx.map(function (x) { return x & 15; }); }

G.registerTab({
  id: 'sprites', label: $t('Sprites'), icon: '⚉', group: $t('Grafik'), needsRom: true,
  render: function (v) {
    var sets = G.cached('sprites', G.spriteCatalog);
    var kinds = [$t('Asterix & Obelix'), $t('Gegner'), $t('Figuren')];
    if (!state.kind) state.kind = kinds[0];
    v.appendChild(el('h2', { text: $t('Sprites') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Vorgerenderte Figuren-Animationen: Asterix und Obelix, Gegner, Dorfbewohner. ') +
      $t('4 Bit (16 Farben einer Palettenbank), Index 0 = durchsichtig. Ein Einzelbild in anderer Groesse importieren stellt das Bild auf die neue Groesse um; Bogen-Export/-Import erledigt ganze Serien auf einmal.') }));
    var tb = el('div', { class: 'toolbar' });
    kinds.forEach(function (k) {
      var n = sets.filter(function (s) { return s.kind === k; }).length;
      tb.appendChild(G.button(k + ' (' + n + ')', function () { state.kind = k; state.set = 0; state.frame = 0; state.pal = null; G.refreshTab(); }, state.kind === k ? 'on' : ''));
    });
    v.appendChild(tb);
    var mine = sets.filter(function (s) { return s.kind === state.kind; });
    var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '230px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
    var list = el('div', { class: 'list', style: { maxHeight: 'calc(100vh - 290px)' } });
    mine.forEach(function (s, i) {
      list.appendChild(el('div', { class: 'it' + (i === state.set ? ' sel' : ''), onclick: function () { state.set = i; state.frame = 0; state.pal = null; G.refreshTab(); } },
        [el('span', { class: 'grow', text: s.name }), el('small', { text: uniqFrames(s).length + ' B.' })]));
    });
    side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
    var set = mine[state.set];
    if (!set) { main.appendChild(el('div', { class: 'card', text: $t('Keine Sprites in dieser Gruppe.') })); return; }
    if (state.pal === null) setDefaults(set);
    var P = curPal(), frames = uniqFrames(set);
    if (state.frame >= frames.length) state.frame = 0;
    var f = frames[state.frame];

    main.appendChild(el('div', { class: 'toolbar' }, [el('span', { class: 'mut', text: $t('Palette') }),
      G.select(palOptions(), state.pal, function (x) { state.pal = +x; G.refreshTab(); }),
      G.select([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map(function (b) { return { value: b, label: $t('Bank ') + b }; }), state.bank, function (x) { state.bank = +x; G.refreshTab(); }),
      el('span', { class: 'hint', text: $t('Nur Vorschau/Export - die Farben selbst stehen im Tab "Paletten".') })]));
    var big = G.idxCanvas(framePx(f), f.w, f.h, P, true);
    var zv = G.zoomView(big, 4);
    main.appendChild(el('div', { class: 'toolbar' }, [el('b', { text: set.name + $t(' - Bild ') + (state.frame + 1) + '/' + frames.length }), zv.ctl]));
    main.appendChild(el('div', { class: 'infobar' }, [
      el('span', { html: $t('Groesse <b>') + f.w + 'x' + f.h + '</b>' }), el('span', { html: $t('Ursprung <b>') + f.ox + ',' + f.oy + '</b>' }),
      el('span', { html: $t('Daten <b>') + G.hx(f.px) + '</b>' }), el('span', { html: $t('Eintrag <b>') + G.hx(f.at) + '</b>' })
    ]));
    main.appendChild(el('div', { class: 'row', style: { alignItems: 'flex-start' } }, [zv.wrap,
      el('div', { class: 'card', style: { minWidth: '260px' } }, [
        el('h4', { text: $t('Einzelbild') }),
        el('div', { class: 'row' }, [
          G.button($t('PNG exportieren'), function () { G.exportPNG('sprite_' + G.hex(f.px, 6) + '_' + f.w + 'x' + f.h + '.png', framePx(f), f.w, f.h, P, true); }, 'primary'),
          G.button($t('PNG importieren ...'), async function () {
            var file = await G.pickFile('image/*'); if (!file) return;
            try {
              var im = await G.readImageFile(file);
              if (im.w !== f.w || im.h !== f.h) {
                if (im.w > 255 || im.h > 255) throw new Error($t('Maximal 255x255 Pixel.'));
                if (!await G.confirmBox($t('Neue Groesse'), $t('Das Bild ist ') + im.w + 'x' + im.h + $t(' statt ') + f.w + 'x' + f.h + $t('. Einzelbild auf die neue Groesse umstellen? (Pixeldaten werden neu angelegt, der Ursprung wird mitskaliert.)'), $t('Umstellen'))) return;
                var r2 = await G.importIndexed(file, im.w, im.h, P, { lo: 1, hi: 15, transparent0: true });
                resizeFrame(f, im.w, im.h, to16(r2.idx));
                G.toast($t('Einzelbild auf ') + im.w + 'x' + im.h + $t(' umgestellt.')); G.refreshTab(); return;
              }
              var r = await G.importIndexed(file, f.w, f.h, P, { lo: 1, hi: 15, transparent0: true });
              if (writeFrame(f, to16(r.idx))) { G.toast($t('Bild ersetzt (') + r.mode + ').'); G.refreshTab(); } else G.toast($t('Unveraendert.'));
            } catch (e) { G.toast(e.message, 'err'); }
          })
        ]),
        el('h4', { text: $t('Ganze Serie (Bogen)'), style: { marginTop: '12px' } }),
        el('div', { class: 'row' }, [
          G.button($t('Bogen exportieren'), function () { var sh = sheetOf(frames); G.exportPNG('spriteset_' + set.id + '_' + sh.cw + 'x' + sh.ch + '.png', sh.idx, sh.w, sh.h, P, true); }),
          G.button($t('Bogen importieren ...'), async function () {
            var file = await G.pickFile('image/*'); if (!file) return;
            try {
              var sh = sheetOf(frames), r = await G.importIndexed(file, sh.w, sh.h, P, { lo: 1, hi: 15, transparent0: true });
              var n = sheetImport(frames, sh, to16(r.idx), sh.w); G.toast(n + $t(' Bilder geaendert.')); G.refreshTab();
            } catch (e) { G.toast(e.message, 'err'); }
          })
        ]),
        el('p', { class: 'hint', text: $t('Bogen: ') + SHEET_COLS + $t(' Bilder pro Zeile, jede Zelle so gross wie das groesste Bild, Bild oben links in der Zelle. Durchsichtig = Index 0 oder Alpha. Indizierte PNGs: es zaehlen die unteren 4 Bit.') })
      ])]));
    var fr = el('div', { class: 'frames', style: { marginTop: '10px' } });
    frames.forEach(function (x, k) {
      var c = G.idxCanvas(framePx(x), x.w, x.h, P, true); c.style.width = (x.w * 1.5) + 'px';
      fr.appendChild(el('div', { class: 'fr' + (k === state.frame ? ' sel' : ''), onclick: function () { state.frame = k; G.refreshTab(); } }, [c, el('small', { text: String(k + 1) })]));
    });
    main.appendChild(fr);
  }
});

function defaultPal(s) {
  var keep = [state.pal, state.bank];
  setDefaults(s); var P = curPal();
  state.pal = keep[0]; state.bank = keep[1];
  return P;
}
G.spritesExportAll = function (zip) {
  var sets = G.cached('sprites', G.spriteCatalog);
  sets.forEach(function (s) { var sh = sheetOf(uniqFrames(s)); zip.add('sprites/spriteset_' + s.id + '_' + sh.cw + 'x' + sh.ch + '.png', G.pngWriteIndexed(sh.idx, sh.w, sh.h, defaultPal(s), true)); });
  return sets.length;
};
G.spritesImportFile = function (name, bytes, report) {
  var m = /spriteset_(spr_[0-9A-F]{6})_/i.exec(name);
  if (!m) return false;
  var sets = G.cached('sprites', G.spriteCatalog), s = sets.filter(function (x) { return x.id.toUpperCase() === m[1].toUpperCase(); })[0];
  if (!s) { report.skip.push(name + $t(': unbekannter Satz')); return true; }
  var frames = uniqFrames(s), sh = sheetOf(frames), png = G.pngRead(bytes);
  if (png.w !== sh.w || png.h !== sh.h) { report.skip.push(name + $t(': Groesse ') + png.w + 'x' + png.h + $t(' statt ') + sh.w + 'x' + sh.h); return true; }
  var idx = png.mode === 'P' ? to16(png.idx) : G.quantize(png.rgba, sh.w, sh.h, defaultPal(s), 1, 15, { transparent0: true });
  var n = sheetImport(frames, sh, idx, sh.w);
  if (n) report.done.push(s.name + ' (' + n + $t(' Bilder)'));
  return true;
};
})(window);
