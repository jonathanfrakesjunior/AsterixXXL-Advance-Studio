/* Asterix XXL Advance Studio - tab_rom.js : ROM-Uebersicht und Projekt */
(function (global) {
'use strict';
var G = global.AXS, el = G.el;

G.registerTab({
  id: 'rom', label: $t('ROM & Projekt'), icon: '▣', group: $t('Allgemein'), needsRom: true,
  render: function (v) {
    var r = G.App.rom, P = G.App.project;
    v.appendChild(el('h2', { text: $t('ROM & Projekt') }));
    v.appendChild(el('p', { class: 'lead', text: $t('Kopfdaten, freier Speicher, Projektdateien und Patches.') }));
    var ok = r.sha1 === G.K.SHA1;
    var free = G.ROM_MAX - r.freeStart();
    var grid = el('div', { class: 'grid2' });
    grid.appendChild(el('div', { class: 'card' }, [
      el('h4', { text: 'ROM' }),
      el('div', { class: 'kv' }, [
        el('b', { text: $t('Datei') }), el('span', { text: r.name }),
        el('b', { text: $t('Titel / Code') }), el('span', { text: r.title() + ' / ' + r.code() }),
        el('b', { text: $t('Groesse') }), el('span', { text: (r.data.length / 1048576) + $t(' MB') + (r.data.length > r.origSize ? $t(' (erweitert)') : '') }),
        el('b', { text: $t('SHA-1 (geladen)') }), el('span', { class: 'mono', text: r.sha1 }),
        el('b', { text: $t('Status') }), el('span', { html: ok ? $t('<span style="color:var(--ok)">Original Asterix & Obelix XXL (Europe) erkannt</span>') : $t('<span style="color:var(--warn)">weicht vom Original ab</span>') }),
        el('b', { text: $t('Kopf-Pruefsumme') }), el('span', { text: r.headerOk() ? $t('korrekt') : $t('wird beim Speichern korrigiert') }),
        el('b', { text: $t('Freier Platz') }), el('span', { text: G.hx(r.freeStart()) + ' - ' + (Math.max(0, r.data.length - r.freeStart()) / 1024 | 0) + $t(' KB in der Datei, ') + (free / 1024 | 0) + $t(' KB bis 16 MB') }),
        el('b', { text: $t('Geaendert') }), el('span', { text: r.changedBytes().toLocaleString('de-DE') + $t(' Bytes') })
      ]),
      el('div', { class: 'row', style: { marginTop: '10px' } }, [
        G.button($t('ROM speichern (.gba)'), G.saveRom, 'primary'),
        r.data.length < G.ROM_MAX ? G.button($t('Auf 16 MB erweitern'), async function () {
          if (!await G.confirmBox($t('ROM erweitern'), $t('Die ROM wird auf 16 MB aufgefuellt. Das schafft Platz fuer groessere Musik, Bilder und Texte. Emulatoren und Flashkarten kommen damit problemlos zurecht.'))) return;
          r.expandTo(G.ROM_MAX); G.logChange($t('ROM auf 16 MB erweitert')); G.refreshTab();
        }) : null
      ])
    ]));
    var nameIn = el('input', { value: P.name, style: { width: '100%' }, oninput: function () { P.name = this.value; } });
    var notes = el('textarea', { rows: 4, style: { width: '100%' }, oninput: function () { P.notes = this.value; } }, [P.notes]);
    grid.appendChild(el('div', { class: 'card' }, [
      el('h4', { text: $t('Projekt') }),
      el('label', { class: 'hint', text: $t('Name') }), nameIn,
      el('label', { class: 'hint', text: $t('Notizen') }), notes,
      el('div', { class: 'row', style: { marginTop: '8px' } }, [
        G.button($t('Projekt speichern'), G.saveProject, 'primary'),
        G.button($t('Projekt laden'), async function () { var f = await G.pickFile('.axstudio,.json'); if (f) G.loadProject(f); }),
        G.button($t('IPS-Patch erzeugen'), function () {
          r.fixHeader();
          var res = G.buildIPS(r.base, r.data);
          var chk = G.applyIPS(r.base, res.patch);
          if (!G.bytesEqual(chk.subarray(0, r.data.length), r.data)) { G.toast($t('IPS-Selbsttest fehlgeschlagen'), 'err'); return; }
          G.download((P.name || 'asterix_mod').replace(/[^\w\-]+/g, '_') + '.ips', res.patch);
          G.toast($t('IPS-Patch erzeugt: ') + res.records + $t(' Datensaetze') + (res.wide ? $t(' (IPS32 wegen >16 MB-Offsets)') : ''));
        }, '', $t('Patch zum Weitergeben ohne ROM')),
        G.button($t('Alles zuruecksetzen'), async function () {
          if (!await G.confirmBox($t('Zuruecksetzen'), $t('Alle Aenderungen verwerfen und zur Original-ROM zurueckkehren?'), $t('Verwerfen'))) return;
          r.resetAll(); G.App.log = []; G.invalidate(); G.refreshTab(); G.toast($t('Alle Aenderungen verworfen.'));
        }, 'danger')
      ])
    ]));
    v.appendChild(grid);

    /* Inhaltsuebersicht */
    var sum = el('div', { class: 'card' }, [el('h4', { text: $t('Inhalt der ROM') })]);
    try {
      var imgs = G.cached('images', G.imageCatalog), tiles = G.cached('tiles', G.tileCatalog), spr = G.cached('sprites', G.spriteCatalog);
      var snd = G.soundInfo(), lv = G.levels();
      var t = el('table', { class: 'tbl' }, [el('tr', {}, [el('th', { text: $t('Bereich') }), el('th', { text: $t('Anzahl') }), el('th', { text: $t('Hinweis') })])]);
      [[$t('Vollbilder & Texturen (VC)'), imgs.length, $t('Menues, Zwischensequenzen, 6 Welt-Texturatlanten')],
       [$t('Kachel-Grafiken'), tiles.length, $t('HUD, Shop, 6 Himmel-Panoramen')],
       [$t('Sprite-Saetze'), spr.length, spr.reduce(function (a, s) { return a + s.frames.length; }, 0) + $t(' Einzelbilder, 4 Bit')],
       [$t('Songs'), snd.songs.length, 'GBAMOD30'],
       [$t('Instrumente'), snd.samples.length, $t('8-Bit-PCM')],
       [$t('Soundeffekte'), snd.effects.length, $t('8-Bit-PCM')],
       [$t('Level'), lv.length, $t('31 Abenteuer-Etappen + 12 Glissobelix-Strecken in 6 Welten')]
      ].forEach(function (x) { t.appendChild(el('tr', {}, [el('td', { text: x[0] }), el('td', { text: String(x[1]) }), el('td', { class: 'mut', text: x[2] })])); });
      sum.appendChild(t);
    } catch (e) { sum.appendChild(el('div', { class: 'warnbox', text: $t('Uebersicht nicht verfuegbar: ') + e.message })); }
    v.appendChild(sum);

    var lg = el('div', { class: 'card' }, [el('h4', { text: $t('Aenderungsprotokoll (diese Sitzung)') })]);
    if (!G.App.log.length) lg.appendChild(el('div', { class: 'hint', text: $t('Noch keine Aenderungen.') }));
    else {
      var ul = el('div', { class: 'list', style: { maxHeight: '260px' } });
      G.App.log.slice().reverse().forEach(function (e) { ul.appendChild(el('div', { class: 'it' }, [el('small', { text: e.t }), el('span', { class: 'grow', text: e.text })])); });
      lg.appendChild(ul);
    }
    v.appendChild(lg);
  }
});
})(window);
