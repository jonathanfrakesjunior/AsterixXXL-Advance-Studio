/* Asterix XXL Advance Studio - tab_start.js */
(function (global) {
'use strict';
var G = global.AXS, el = G.el;

G.registerTab({
  id: 'start', label: $t('Start'), icon: '⌂', group: $t('Allgemein'),
  render: function (v) {
    v.appendChild(el('div', { class: 'hero' }, [
      el('h1', { html: 'Asterix XXL Advance Studio' }),
      el('p', { class: 'lead', html: $t('Mod-Werkzeug fuer <b>Asterix & Obelix XXL</b> (Game Boy Advance, Europe). Laeuft komplett im Browser - ') +
        $t('keine Installation, kein Server. Alle Aenderungen bleiben im Speicher, bis du sie als neue ROM oder als Projekt sicherst. ') +
        $t('Die Original-Datei wird nie veraendert.') }),
      el('div', { class: 'row' }, [
        G.button($t('ROM laden'), function () { G.$('btnLoadRom').click(); }, 'primary'),
        G.App.rom ? G.button($t('Zur ROM-Uebersicht'), function () { G.selectTab('rom'); }) : null,
        el('span', { class: 'hint', text: $t('oder die .gba-Datei einfach ins Fenster ziehen') })
      ])
    ]));
    var feats = [
      [$t('Level-Editor'), $t('Alle 43 Level (6 Welten + Glissobelix) aus den echten 3D-Daten texturiert von oben: Boden bemalen, Gelaende anheben/absenken, Startpunkt setzen, Objekte verschieben, kopieren und loeschen, Textur-Rahmen und Level-Palette bearbeiten.')],
      [$t('Bilder & Texturen'), $t('Menues, Titel und alle Zwischensequenz-Bilder (240x160) sowie die sechs Welt-Texturatlanten (256x656) als PNG heraus und wieder hinein. Kompression (VC) erledigt das Studio.')],
      [$t('Sprites'), $t('Asterix, Obelix, Gegner und Dorfbewohner: ueber 3600 Einzelbilder einzeln (auch in neuer Groesse) oder als Bogen ex- und importieren.')],
      [$t('HUD & Himmel'), $t('HUD-Grafiken, Shop-Beschriftungen und die sechs Himmel-Panoramen der Welten.')],
      [$t('Paletten'), $t('Alle 73 Palettendateien direkt bearbeiten, als .pal/.act/.png sichern und laden.')],
      [$t('Texte'), $t('Menues, Untertitel der Zwischensequenzen, Dialoge, Shop und Abspann in allen 6 Sprachen nebeneinander. Laengere Texte werden automatisch verschoben.')],
      [$t('Sound & Musik'), $t('11 Songs (Tracker-Format GBAMOD30) anhoeren, als WAV/MIDI exportieren, MIDI importieren. Instrumente und 42 Effekte als WAV tauschen.')],
      [$t('Komplett-Paket'), $t('Alles auf einmal als ZIP exportieren, extern bearbeiten und wieder einspielen - ideal fuer Total Conversions.')]
    ];
    var f = el('div', { class: 'feat' });
    feats.forEach(function (x) { f.appendChild(el('div', { class: 'f' }, [el('b', { text: x[0] }), el('span', { text: x[1] })])); });
    v.appendChild(f);
    v.appendChild(el('h3', { text: $t('So geht es') }));
    v.appendChild(el('ol', { class: 'steps' }, [
      el('li', { text: $t('Eigene, legal erstellte ROM von "Asterix & Obelix XXL (Europe)" laden (BLXP, 8 MB).') }),
      el('li', { text: $t('Links einen Bereich waehlen, Inhalte exportieren, bearbeiten und wieder importieren.') }),
      el('li', { text: $t('Unter "ROM & Projekt" regelmaessig das Projekt sichern (.axstudio - enthaelt nur deine Aenderungen).') }),
      el('li', { text: $t('"ROM speichern" erzeugt die fertige .gba (Kopf-Pruefsumme wird korrigiert). In mGBA testen.') })
    ]));
    v.appendChild(el('p', { class: 'hint', html: $t('Erwartete ROM: SHA-1 <span class="mono">') + G.K.SHA1 + $t('</span>. Grosse Umbauten koennen die ROM auf 16 MB erweitern ') +
      $t('(mehr geht wegen des EEPROM-Speicherstands nicht).') }));
  }
});
})(window);
