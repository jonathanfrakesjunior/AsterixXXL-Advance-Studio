/* Asterix XXL Advance Studio - tab_text.js : Texte in 6 Sprachen (FR EN DE ES IT NL)
   Textbloecke liegen zwischen K.TEXT_START und K.TEXT_END und werden ueber Zeigertabellen angesprochen:
   - 'pos' (Menues):   Zeilen {u8 x, u8 y, Text, 0} ... 0xFF
   - 'sub' (Untertitel/Dialoge): Seiten aus Zeilen {Text, 0} ... 0xFF, mehrere Seiten hintereinander
   - 'fix' (Shop):     20 Zeichen ohne Endezeichen
   Laengere Texte werden ans ROM-Ende verschoben und alle Zeiger auf den Block umgebogen. */
(function (global) {
'use strict';
var G = global.AXS, el = G.el;
var LANGS = ['FR', 'EN', 'DE', 'ES', 'IT', 'NL'];
var TABLES = [
  { id: 'neu', name: $t('Menue: Spiel anlegen/laden'), at: 0x510BC, n: 18, kind: 'pos' },
  { id: 'haupt', name: $t('Hauptmenue'), at: 0x51574, n: 6, kind: 'pos' },
  { id: 'optionen', name: $t('Optionen'), at: 0x518DC, n: 12, kind: 'pos' },
  { id: 'pause', name: $t('Pause/Karte'), at: 0x51C18, n: 12, kind: 'pos' },
  { id: 'erfolg', name: $t('Erfolg'), at: 0x51F50, n: 6, kind: 'pos' },
  { id: 'prozent', name: $t('100 % geschafft'), at: 0x520A4, n: 6, kind: 'pos' },
  { id: 'lorbeer', name: $t('Alle Lorbeeren'), at: 0x522D8, n: 6, kind: 'pos' },
  { id: 'super', name: $t('Super 100 %'), at: 0x524EC, n: 6, kind: 'pos' },
  { id: 'speichern', name: $t('Speichern'), at: 0x53968, n: 6, kind: 'pos' },
  { id: 'laden', name: $t('Laden'), at: 0x53A58, n: 6, kind: 'pos' },
  { id: 'welten', name: $t('Glissobelix-Strecken'), at: 0x5919C, n: 72, kind: 'pos' },
  { id: 'zeit', name: $t('Zeit'), at: 0x59630, n: 6, kind: 'pos' },
  { id: 'janein', name: $t('Ja/Nein & Pausemenue'), at: 0x5C364, n: 18, kind: 'pos' },
  { id: 'credits', name: $t('Abspann'), at: 0x53BA0, n: 43, kind: 'pos', single: true },
  { id: 'zs', name: $t('Zwischensequenzen'), at: 0x59AC8, n: 360, kind: 'sub' },
  { id: 'dialog', name: $t('Dialoge im Spiel'), at: 0x5C690, n: 126, kind: 'sub' },
  { id: 'shop', name: $t('Shop'), at: 0x61380, n: 6 * 8, kind: 'fix', stride: 0x28, per: 6 }
];
var state = { table: 0, filter: '' };

function D() { return G.App.rom.data; }
/* Shop: 7 Gruppen zu je 6 Zeigern, Gruppenabstand 0x28 */
function slotAddr(T, i) {
  if (T.stride) return T.at + ((i / T.per) | 0) * T.stride + 4 * (i % T.per);
  return T.at + 4 * i;
}
function allTargets() {
  return G.cached('txtTargets', function () {
    var s = {};
    TABLES.forEach(function (T) { for (var i = 0; i < T.n; i++) { var p = G.ptr(slotAddr(T, i)); if (p >= 0) s[p] = 1; } });
    return Object.keys(s).map(Number).sort(function (a, b) { return a - b; });
  });
}
function nextTarget(off) {
  var t = allTargets();
  for (var i = 0; i < t.length; i++) if (t[i] > off) return t[i];
  return off + 4096;
}
function readZ(p, lim) { var d = D(), s = ''; while (p < lim && d[p] !== 0) s += String.fromCharCode(d[p++]); return { s: s, end: p }; }

/* Block lesen -> {kind, off, len, lines|pages|text} */
function readBlock(T, off) {
  var d = D(), p = off, lim = Math.min(d.length, off + 4000);
  if (T.kind === 'fix') { var s = ''; for (var i = 0; i < 20; i++) s += String.fromCharCode(d[off + i]); return { kind: 'fix', off: off, len: 20, text: s }; }
  if (T.kind === 'pos') {
    var lines = [];
    while (p < lim && d[p] !== 0xFF) { var x = d[p], y = d[p + 1], z = readZ(p + 2, lim); lines.push({ x: x, y: y, s: z.s }); p = z.end + 1; }
    return { kind: 'pos', off: off, len: p + 1 - off, lines: lines };
  }
  var end = Math.min(nextTarget(off), lim), pages = [], cur = [];
  while (p < end) {
    if (d[p] === 0xFF) { pages.push(cur); cur = []; p++; if (d[p] === 0) break; continue; }
    if (d[p] === 0) { p++; continue; }
    var z2 = readZ(p, end); cur.push(z2.s); p = z2.end + 1;
  }
  if (cur.length) pages.push(cur);
  /* Block endet hinter dem letzten 0xFF */
  var last = off; for (var q = off; q < p; q++) if (d[q] === 0xFF) last = q + 1;
  return { kind: 'sub', off: off, len: last - off, pages: pages };
}
function enc(s) { var o = []; for (var i = 0; i < s.length; i++) o.push(s.charCodeAt(i) & 255); return o; }
function buildBlock(b) {
  var o = [];
  if (b.kind === 'fix') { var t = (b.text + '                    ').slice(0, 20); return new Uint8Array(enc(t)); }
  if (b.kind === 'pos') { b.lines.forEach(function (l) { o.push(l.x, l.y); o = o.concat(enc(l.s)); o.push(0); }); o.push(0xFF); return new Uint8Array(o); }
  b.pages.forEach(function (pg) { pg.forEach(function (l) { o = o.concat(enc(l)); o.push(0); }); o.push(0xFF); });
  return new Uint8Array(o);
}
/* Text <-> Editorform */
function blockToText(b) {
  if (b.kind === 'fix') return b.text.replace(/\s+$/, '');
  if (b.kind === 'pos') return b.lines.map(function (l) { return l.s; }).join('\n');
  return b.pages.map(function (pg) { return pg.join('\n'); }).join('\n---\n');
}
function textToBlock(b, text) {
  var nb = JSON.parse(JSON.stringify(b));
  text = text.replace(/\r/g, '');
  if (b.kind === 'fix') { nb.text = text; return nb; }
  if (b.kind === 'pos') {
    var ls = text.split('\n');
    if (ls.length !== b.lines.length) throw new Error($t('Bitte genau ') + b.lines.length + $t(' Zeilen behalten (jede Zeile hat eine feste Bildschirmposition).'));
    ls.forEach(function (s, i) { nb.lines[i].s = s; });
    return nb;
  }
  var pgs = text.split(/\n---\n/);
  if (pgs.length !== b.pages.length) throw new Error($t('Bitte genau ') + b.pages.length + $t(' Seiten behalten (getrennt durch eine Zeile ---).'));
  nb.pages = pgs.map(function (p) { return p.split('\n').filter(function (l, i, a) { return l.length || a.length === 1; }); });
  return nb;
}
/* erlaubte Zeichen = alle Zeichen, die in den Original-Texten vorkommen */
function charset() {
  return G.cached('txtChars', function () {
    var ok = {}; ok[32] = 1;
    TABLES.forEach(function (T) {
      for (var i = 0; i < T.n; i++) {
        var p = G.ptr(slotAddr(T, i)); if (p < 0) continue;
        var t = blockToText(readBlock(T, p));
        for (var k = 0; k < t.length; k++) ok[t.charCodeAt(k)] = 1;
      }
    });
    return ok;
  });
}
function clean(text) {
  var ok = charset(), out = '', bad = {};
  text = text.toUpperCase().replace(/ß/g, 'SS');
  for (var i = 0; i < text.length; i++) {
    var c = text.charAt(i), k = text.charCodeAt(i);
    if (c === '\n' || ok[k]) out += c;
    else { var plain = c.normalize ? c.normalize('NFD').replace(/[̀-ͯ]/g, '') : c; if (plain.length === 1 && ok[plain.charCodeAt(0)]) out += plain; else { bad[c] = 1; out += ' '; } }
  }
  return { text: out, bad: Object.keys(bad) };
}
function writeBlock(T, slot, text) {
  var off = G.ptr(slotAddr(T, slot)), b = readBlock(T, off), c = clean(text);
  var nb = textToBlock(b, c.text), bytes = buildBlock(nb), old = buildBlock(b);
  if (G.bytesEqual(bytes, old)) return { same: true, bad: c.bad };
  var d = D(), res;
  if (bytes.length <= b.len) {
    d.set(bytes, off); for (var i = off + bytes.length; i < off + b.len; i++) d[i] = 0;
    res = { off: off, moved: false };
  } else {
    var refs = []; TABLES.forEach(function (T2) { for (var j = 0; j < T2.n; j++) if (G.ptr(slotAddr(T2, j)) === off) refs.push(slotAddr(T2, j)); });
    var withEnd = new Uint8Array(bytes.length + 1); withEnd.set(bytes);   /* 0 hinter dem letzten 0xFF = Blockende */
    res = G.replaceBlob(off, b.len, withEnd, { refs: refs });
  }
  G.logChange($t('Text ') + T.name + ' ' + LANGS[slot % 6] + ' #' + ((slot / 6) | 0) + (res.moved ? $t(' (verschoben nach ') + G.hx(res.off) + ')' : ''));
  G.invalidate(['txtTargets']);
  return { res: res, bad: c.bad };
}

G.registerTab({
  id: 'text', label: $t('Texte'), icon: '¶', group: $t('Inhalt'), needsRom: true,
  render: function (v) {
    v.appendChild(el('h2', { text: $t('Texte') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Alle Texte in den sechs Sprachen des Spiels nebeneinander: Menues, Untertitel der Zwischensequenzen, Dialoge, Shop und Abspann. ') +
      $t('Die Spielschrift kennt nur Grossbuchstaben (Kleinbuchstaben werden umgewandelt). Menuezeilen haben feste Positionen - Zeilenzahl beibehalten. ') +
      $t('Untertitel: Seiten mit einer Zeile <span class="mono">---</span> trennen. Laengere Texte werden automatisch verschoben.') }));
    var tb = el('div', { class: 'toolbar' }, [
      G.select(TABLES.map(function (T, i) { return { value: i, label: T.name + ' (' + (T.single ? T.n : T.n / 6) + ')' }; }), state.table, function (x) { state.table = +x; G.refreshTab(); }),
      el('input', { placeholder: $t('Suchen ...'), value: state.filter, style: { width: '200px' }, onchange: function () { state.filter = this.value; G.refreshTab(); } }),
      el('span', { class: 'spacer' }),
      G.button($t('CSV exportieren'), function () { G.download('asterix_texte.csv', new TextEncoder().encode(G.textsCSV()), 'text/csv'); }),
      G.button($t('CSV importieren ...'), async function () {
        var f = await G.pickFile('.csv,.txt'); if (!f) return;
        var rep = { done: [], skip: [] }; G.textsImportCSV(await G.readFileText(f), rep);
        G.modal($t('CSV importiert'), '<p>' + rep.done.length + $t(' Texte geaendert.</p>') + (rep.skip.length ? '<div class="warnbox">' + rep.skip.slice(0, 40).join('<br>') + '</div>' : ''));
        G.refreshTab();
      })
    ]);
    v.appendChild(tb);
    var T = TABLES[state.table], rows = T.single ? T.n : T.n / 6, filt = state.filter.toUpperCase();
    var box = el('div');
    for (var r = 0; r < rows && box.childNodes.length < 80; r++) {
      var cells = [], texts = [], hit = !filt;
      var slots = T.single ? [r] : [0, 1, 2, 3, 4, 5].map(function (l) { return r * 6 + l; });
      slots.forEach(function (sl) {
        var off = G.ptr(slotAddr(T, sl)); var t = off >= 0 ? blockToText(readBlock(T, off)) : '';
        texts.push({ sl: sl, off: off, t: t }); if (filt && t.toUpperCase().indexOf(filt) >= 0) hit = true;
      });
      if (!hit) continue;
      var grid = el('div', { class: 'txtgrid', style: { display: 'grid', gridTemplateColumns: T.single ? '1fr' : 'repeat(3, 1fr)', gap: '6px' } });
      texts.forEach(function (x) {
        var n = x.t.split('\n').length;
        var ta = el(T.kind === 'fix' ? 'input' : 'textarea', { rows: Math.min(14, Math.max(2, n)), value: x.t, style: { width: '100%' }, maxlength: T.kind === 'fix' ? 20 : null });
        if (T.kind !== 'fix') ta.value = x.t;
        var lab = el('div', { class: 'mut', style: { fontSize: '11px' }, text: (T.single ? '' : LANGS[x.sl % 6] + ' · ') + G.hx(x.off) });
        ta.onchange = function () {
          try {
            var w = writeBlock(T, x.sl, ta.value);
            if (w.bad && w.bad.length) G.toast($t('Nicht darstellbare Zeichen durch Leerzeichen ersetzt: ') + w.bad.join(' '), 'warn');
            else if (!w.same) G.toast($t('Gespeichert') + (w.res.moved ? $t(' (verschoben)') : '') + '.');
            G.updateStatus();
          } catch (e) { G.toast(e.message, 'err'); }
        };
        grid.appendChild(el('div', {}, [lab, ta]));
      });
      box.appendChild(el('div', { class: 'card' }, [el('h4', { text: T.name + ' #' + r }), grid]));
    }
    if (!box.childNodes.length) box.appendChild(el('div', { class: 'card', text: $t('Keine Treffer.') }));
    v.appendChild(box);
  }
});

/* ---------------------------------------------------------------- CSV */
function csvCell(s) { return '"' + String(s).replace(/"/g, '""') + '"'; }
G.textsCSV = function () {
  var out = ['"id";"FR";"EN";"DE";"ES";"IT";"NL"'];
  TABLES.forEach(function (T) {
    var rows = T.single ? T.n : T.n / 6;
    for (var r = 0; r < rows; r++) {
      var line = [csvCell(T.id + ':' + r)];
      var slots = T.single ? [r] : [0, 1, 2, 3, 4, 5].map(function (l) { return r * 6 + l; });
      slots.forEach(function (sl) { var off = G.ptr(slotAddr(T, sl)); line.push(csvCell(off >= 0 ? blockToText(readBlock(T, off)) : '')); });
      out.push(line.join(';'));
    }
  });
  return '﻿' + out.join('\r\n') + '\r\n';
};
function csvParse(txt) {
  txt = txt.replace(/^﻿/, '');
  var sep = txt.indexOf(';') >= 0 && (txt.indexOf(';') < txt.indexOf(',') || txt.indexOf(',') < 0) ? ';' : ',';
  var rows = [], row = [], cell = '', q = false;
  for (var i = 0; i < txt.length; i++) {
    var c = txt.charAt(i);
    if (q) { if (c === '"') { if (txt.charAt(i + 1) === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === sep) { row.push(cell); cell = ''; }
    else if (c === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell.length || row.length) { row.push(cell); rows.push(row); }
  return rows;
}
G.textsImportCSV = function (txt, rep) {
  var rows = csvParse(txt);
  rows.forEach(function (r) {
    var m = /^(\w+):(\d+)$/.exec(r[0] || ''); if (!m) return;
    var T = TABLES.filter(function (x) { return x.id === m[1]; })[0]; if (!T) { rep.skip.push(r[0] + $t(': unbekannt')); return; }
    var row = +m[2], langs = T.single ? 1 : 6;
    for (var l = 0; l < langs; l++) {
      if (r[l + 1] === undefined) continue;
      var sl = T.single ? row : row * 6 + l, off = G.ptr(slotAddr(T, sl)); if (off < 0) continue;
      if (blockToText(readBlock(T, off)) === r[l + 1].replace(/\r/g, '')) continue;
      try { var w = writeBlock(T, sl, r[l + 1]); if (!w.same) rep.done.push(T.name + ' #' + row + ' ' + (T.single ? '' : LANGS[l])); }
      catch (e) { rep.skip.push(r[0] + ' ' + LANGS[l] + ': ' + e.message); }
    }
  });
};
G.textTables = TABLES;
})(window);
