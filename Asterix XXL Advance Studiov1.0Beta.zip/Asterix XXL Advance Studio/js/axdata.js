/* Asterix XXL Advance Studio - axdata.js
   Wissen ueber die ROM "Asterix & Obelix XXL (Europe)" (BLXP, 8 MB, VD-dev-Engine wie Driv3r) und
   Kataloge aller Inhalte. Adressen sind ROM-Offsets (ohne 0x08000000). Zeiger werden, wo moeglich,
   live aus der ROM gelesen, damit verschobene Daten gefunden werden. */
(function (global) {
'use strict';
var G = global.AXS;

var K = G.K = {
  SHA1: '7145d02143c1a81f6ea72063ac798642b2aaec3c',
  CODE: 'BLXP',
  PAL_START: 0x47748C, PAL_END: 0x480612,
  LEVEL_TABLE: 0x5B150, LEVEL_COUNT: 43, LEVEL_STRIDE: 0x38,
  LOADLIST_START: 0x5A7C0, LOADLIST_END: 0x5BB58,
  TEXT_START: 0x487A3C, TEXT_END: 0x49571A,
  SND_CFG: 0x67DBE8, SONG_TABLE: 0x67DBB0, SONG_COUNT: 11, SONG_SHIFT: 4, BANK_HDR: 12,
  IMG_BUF: 0x0202F328, LEVEL_RAM: 0x0202E818, LEVEL_MAX: 0xCB2E,
  HERO_PAL: 0x478606,
  LANGS: ['FR', 'EN', 'DE', 'ES', 'IT', 'NL'],
  WORLD_NAMES: [$t('Gallien'), $t('Normandie'), $t('Griechenland'), $t('Helvetien'), $t('Aegypten'), $t('Rom')]
};

function D() { return G.App.rom.data; }
function ptr(o) { var v = G.u32(D(), o); return (v >= 0x08000000 && v < 0x09000000) ? v - 0x08000000 : -1; }
G.ptr = ptr;

/* ---------------------------------------------------------------- Paletten */
/* Paletten-Datei: {u16 Anzahl, u16 Byte-Offset ab 0x05000000, Farben} ... Anzahl 0 */
function parsePalFile(d, off) {
  var p = off, recs = [];
  for (var guard = 0; guard < 8; guard++) {
    var n = G.u16(d, p), o = G.u16(d, p + 2);
    if (n === 0 || n > 512) break;
    recs.push({ n: n, dst: o, off: p + 4 });
    p += 4 + 2 * n;
  }
  return { off: off, recs: recs, end: p + 2 };
}
function paletteFiles() {
  var d = D(), out = [], p = K.PAL_START, names = palNames();
  while (p < K.PAL_END) {
    var f = parsePalFile(d, p);
    if (!f.recs.length) break;
    f.name = names[p] || ($t('Palette ') + G.hx(p));
    out.push(f); p = f.end;
  }
  return out;
}
/* Namen aus der Verwendung ableiten */
function palNames() {
  return G.cached('palnames', function () {
    var n = {};
    n[K.HERO_PAL] = $t('Asterix & Obelix (Objekte 0-31)');
    n[K.HERO_PAL + 0x46] = $t('Asterix & Obelix Variante (Objekte 0-31)');
    worlds().forEach(function (w) { if (!n[w.objPal]) n[w.objPal] = w.name + $t(' - Figuren/Himmel (Objekte 32-255)'); });
    screens().forEach(function (s) { if (s.pal >= 0 && !n[s.pal]) n[s.pal] = s.name; });
    return n;
  });
}
/* Level-Palette: die ersten 512 Byte der (VC-gepackten) Leveldatei */
function levelPal(mapOff) {
  return G.cached('lvpal_' + mapOff, function () {
    var raw = G.vcDecode(D(), mapOff).data, p = [];
    for (var i = 0; i < 256; i++) p.push(G.c15ToRgb(G.u16(raw, 2 * i)));
    return p;
  });
}
/* 256 BG-Farben + 256 OBJ-Farben aus Palettendateien ({lvl: off} = Level-Palette) zusammensetzen */
function composePal(files) {
  var d = D(), bg = [], obj = [], i;
  for (i = 0; i < 256; i++) { bg.push([255, 0, 255]); obj.push([255, 0, 255]); }
  files.forEach(function (off) {
    if (off && typeof off === 'object') { if (off.lvl >= 0) levelPal(off.lvl).forEach(function (c, k) { bg[k] = c; }); return; }
    if (off < 0) return;
    parsePalFile(d, off).recs.forEach(function (r) {
      for (var k = 0; k < r.n; k++) {
        var slot = (r.dst >> 1) + k, c = G.c15ToRgb(G.u16(d, r.off + 2 * k));
        if (slot < 256) bg[slot] = c; else if (slot < 512) obj[slot - 256] = c;
      }
    });
  });
  return { bg: bg, obj: obj };
}
G.parsePalFile = parsePalFile; G.paletteFiles = paletteFiles; G.composePal = composePal; G.levelPal = levelPal;

/* ---------------------------------------------------------------- Level */
/* Level-Eintrag (0x38 Byte): 4 x {Quelle, Ziel} (Texturen -> 0x02000000, Leveldatei -> 0x0202E818,
   Himmel-Kacheln -> 0x06014000, HUD -> 0x06016A00), 0, Variante, Figurenpalette, Himmel-Attribute, 2 Zeiger. */
function levels() {
  return G.cached('levels', function () {
    var out = [], texOrder = [], stage = {};
    for (var i = 0; i < K.LEVEL_COUNT; i++) {
      var rec = K.LEVEL_TABLE + K.LEVEL_STRIDE * i;
      var L = { idx: i, rec: rec, tex: ptr(rec), map: ptr(rec + 8), sky: ptr(rec + 16), hud: ptr(rec + 24),
        variant: G.u32(D(), rec + 0x24), objPal: ptr(rec + 0x28), skyAttr: ptr(rec + 0x2C) };
      var w = texOrder.indexOf(L.tex); if (w < 0) { texOrder.push(L.tex); w = texOrder.length - 1; }
      L.world = w;
      var N = 0; try { N = G.u32(G.vcDecode(D(), L.map).data, 0xB00); } catch (e) { }
      L.N = N;
      if (i >= 31) { var k = (i - 31) % 2; L.bob = true; L.name = 'Glissobelix - ' + K.WORLD_NAMES[w] + ' ' + (k + 1); }
      else {
        stage[w] = (stage[w] || 0) + 1;
        L.name = K.WORLD_NAMES[w] + ' - ' + $t('Etappe ') + stage[w] + (N > 200 ? $t(' (Schlitten)') : '');
      }
      out.push(L);
    }
    return out;
  });
}
function worlds() {
  var seen = {}, out = [];
  levels().forEach(function (L) {
    if (seen[L.world]) return; seen[L.world] = 1;
    out.push({ id: L.world, name: K.WORLD_NAMES[L.world], tex: L.tex, map: L.map, sky: L.sky, skyAttr: L.skyAttr, objPal: L.objPal, level: L });
  });
  return out;
}
G.levels = levels; G.worlds = worlds;

/* ---------------------------------------------------------------- Bildschirme (Ladelisten) */
/* Bildschirm-Eintrag: {Quelle, Ziel}..., 0, Palette, [Text], Routine.
   Vollbilder (240x160, 8 Bit) werden nach 0x0202F328 entpackt, Objektkacheln nach 0x06014000. */
function screens() {
  return G.cached('screens', function () {
    var d = D(), out = [], seen = {};
    for (var a = K.LOADLIST_START; a < K.LOADLIST_END; a += 4) {
      if (a >= K.LEVEL_TABLE && a < K.LEVEL_TABLE + K.LEVEL_COUNT * K.LEVEL_STRIDE) continue;
      var src = ptr(a), dst = G.u32(d, a + 4);
      if (src < 0 || dst !== K.IMG_BUF || !G.isVC(d, src)) continue;
      var q = a; while (q < K.LOADLIST_END && G.u32(d, q) !== 0) q += 8;
      var pal = ptr(q + 4);
      if (pal < K.PAL_START || pal >= K.PAL_END) pal = -1;
      var key = src + '_' + pal; if (seen[key]) continue; seen[key] = 1;
      out.push({ src: src, ref: a, pal: pal, list: q });
    }
    var n = 0;
    out.forEach(function (s) { s.name = $t('Bild ') + (++n) + ' (' + G.hex(s.src, 6) + ')'; });
    return out;
  });
}
G.screens = screens;

/* ---------------------------------------------------------------- Bilder (VC) */
function imageCatalog() {
  var list = [], d = D(), done = {};
  screens().forEach(function (s, i) {
    if (done[s.src]) return; done[s.src] = 1;
    var size = G.vcSize(d, s.src);
    if (size < 0x9600) return;
    list.push({ id: 'scr' + G.hex(s.src, 6), name: $t('Vollbild ') + (list.length + 1), off: s.src, w: 240, h: 160, extra: size - 0x9600,
      pals: [s.pal], group: $t('Vollbilder (Menues, Zwischensequenzen)') });
  });
  worlds().forEach(function (w) {
    list.push({ id: 'tex' + w.id, name: w.name + $t(' - Texturatlas'), off: w.tex, w: 256, h: 656, pals: [{ lvl: w.map }],
      group: $t('Level-Texturen'), world: w.id });
  });
  return list.filter(function (it) { return it.off >= 0 && G.isVC(d, it.off); });
}
/* Kachel-Grafiken fuer Objekte (4 Bit) */
function tileCatalog() {
  var list = [], d = D(), done = {}, skies = {};
  worlds().forEach(function (w) { skies[w.sky] = 1; });
  for (var a = K.LOADLIST_START; a < K.LOADLIST_END; a += 4) {
    var src = ptr(a), dst = G.u32(d, a + 4);
    if (src < 0 || (dst & 0xFFFF0000) !== 0x06010000 || !G.isVC(d, src) || done[src] || skies[src]) continue;
    var dec = null; try { dec = G.vcDecode(d, src); } catch (e) { continue; }
    if (dec.used < 0x20) continue;           /* leerer Puffer */
    done[src] = 1;
    var q = a; while (q < K.LOADLIST_END && G.u32(d, q) !== 0) q += 8;
    var pal = ptr(q + 4); if (pal < K.PAL_START || pal >= K.PAL_END) pal = K.HERO_PAL;
    var isLevel = a >= K.LEVEL_TABLE && a < K.LEVEL_TABLE + K.LEVEL_COUNT * K.LEVEL_STRIDE;
    if (isLevel) pal = K.HERO_PAL;
    list.push({ id: 't' + G.hex(src, 6), name: (isLevel ? $t('HUD (Level)') : $t('Objektkacheln ')) + ' ' + G.hex(src, 6), off: src, bpp: 4, cols: 16,
      pals: isLevel ? [0x477898, K.HERO_PAL] : [pal], bank: 0, group: isLevel ? 'HUD' : $t('Menues & Zwischensequenzen') });
  }
  var extra = [[0xAED9, 'HUD 2'], [0xC02D, $t('HUD, Shop & Ziffern')]];
  extra.forEach(function (x) { if (!done[x[0]] && G.isVC(d, x[0])) { done[x[0]] = 1; list.push({ id: 't' + G.hex(x[0], 6), name: x[1], off: x[0], bpp: 4, cols: 16, pals: [0x478692], bank: 0, group: 'HUD' }); } });
  skylines().forEach(function (s, i) { list.push({ id: 'sky' + i, name: $t('Himmel ') + s.name, off: s.vc, bpp: 4, sky: s, pals: [s.pal], group: $t('Himmel-Panoramen') }); });
  return list;
}
/* Himmel: 6 Spalten x 7 Zeilen aus 32x16-Objekten; Attributtabelle 42 Halbwoerter (zeilenweise) */
function skylines() {
  return worlds().filter(function (w) { return w.sky >= 0 && w.skyAttr >= 0 && G.isVC(D(), w.sky); })
    .map(function (w) { return { vc: w.sky, attr: w.skyAttr, name: w.name, pal: w.objPal, world: w.id }; });
}
G.imageCatalog = imageCatalog; G.tileCatalog = tileCatalog; G.skylines = skylines;

/* ---------------------------------------------------------------- Sprites */
/* Bildeintrag: {s8 ox, s8 oy, u8 w, u8 h, u32 Zeiger} -> 4 Bit linear (hohes Halbbyte = linkes Pixel),
   (w+1)/2 Byte je Zeile, Index 0 durchsichtig. */
function frameSize(w, h) { return ((w + 1) >> 1) * h; }
G.spriteFrameSize = frameSize;
var SET_NAMES = {};
(function () {
  var A = 'Asterix', O = 'Obelix';
  var names = [A, A, O, A, O, $t('Geist'), A, A, A, A, A, A, $t('Geist'), O, O, O, O, O, O, O, O, O, A, A, A, A, A, A, A, A, A, A, A, A, O, A, O, A, O, A, O, A, O,
    A + $t(' (Zaubertrank)'), O + $t(' (Zaubertrank)'), A, A, A, A, A, O, O, O, O, A, A, A, A, A, O, O, A, O, O, O, A, O];
  var addrs = [0x70BBC, 0x7BAA8, 0x7FB14, 0x94A70, 0x99008, 0xA1B30, 0xA1B60, 0xA1BB0, 0xA1C00, 0xA1C50, 0xA1CA0, 0xA1DE0, 0xB3BBC, 0xB3BF4, 0xB3C44, 0xB3C94, 0xB3CE4, 0xB3D2C,
    0xB3D7C, 0xB3DCC, 0xB3E1C, 0xB3E74, 0xD437C, 0xD43AC, 0xD43DC, 0xD440C, 0xD443C, 0xD4464, 0xD4494, 0xD44C4, 0xD44F4, 0xDB854, 0xF58B0, 0xFCBCC, 0x101DC4, 0x10CBB8, 0x1110B0,
    0x11AD7C, 0x11DF70, 0x124550, 0x1321C4, 0x149D30, 0x155B70, 0x1BC568, 0x1BDD68, 0x1C0948, 0x1C0960, 0x1C09A0, 0x1C09E0, 0x1C0A20, 0x1CCD34, 0x1CCEB4, 0x1E256C, 0x1E44F8,
    0x1EC6D8, 0x1F0FDC, 0x1F1004, 0x1F102C, 0x1F1054, 0x1F4AC8, 0x1F9970, 0x1FF508, 0x202630, 0x207BAC, 0x214CAC, 0x227250, 0x231050];
  addrs.forEach(function (a, i) { SET_NAMES[a] = names[i]; });
})();
function spriteCatalog() {
  var d = D(), n = d.length, recs = {};
  function okRec(o) {
    var w = d[o + 2], h = d[o + 3];
    if (w < 2 || h < 2 || d[o + 7] !== 0x08) return null;
    var a = d[o + 4] | (d[o + 5] << 8) | (d[o + 6] << 16);
    if (a + frameSize(w, h) > n) return null;
    var ox = d[o] << 24 >> 24, oy = d[o + 1] << 24 >> 24;
    if (-ox > w + 16 || -oy > h + 16 || ox > 16 || oy > 16) return null;
    return { at: o, ox: ox, oy: oy, w: w, h: h, px: a };
  }
  for (var o = 0; o < n - 8; o += 4) { var r = okRec(o); if (r) recs[o] = r; }
  var keys = Object.keys(recs).map(Number).sort(function (a, b) { return a - b; }), sets = [], cur = null;
  keys.forEach(function (k) {
    var r = recs[k];
    if (cur && k === cur.last + 8) { cur.frames.push(r); cur.last = k; }
    else { if (cur) sets.push(cur); cur = { first: k, last: k, frames: [r] }; }
  });
  if (cur) sets.push(cur);
  sets = sets.filter(function (s) {
    if (s.frames.length < 2) return false;
    var chain = 0;
    for (var i = 1; i < s.frames.length; i++) { var a = s.frames[i - 1]; if (s.frames[i].px === a.px + frameSize(a.w, a.h)) chain++; }
    return chain >= Math.max(1, (s.frames.length - 1) * 0.5);
  });
  /* Palettenbank aus den Animationslisten (Wert vor der Bildliste) */
  var owner = {};
  sets.forEach(function (s, i) { s.frames.forEach(function (f) { owner[f.at] = i; }); s.bankVotes = {}; });
  for (var a = 0x240000; a < Math.min(n, 0x270000); a += 4) {
    var w = G.u32(d, a) & 0x7FFFFFFF;
    if (w < 0x08000000 || w >= 0x08800000) continue;
    var si = owner[w - 0x08000000]; if (si === undefined) continue;
    var pv = G.u32(d, a - 4); if (pv < 16) sets[si].bankVotes[pv] = (sets[si].bankVotes[pv] || 0) + 1;
  }
  var cnt = { h: 0, e: 0, f: 0 };
  sets.forEach(function (s, i) {
    s.id = 'spr_' + G.hex(s.first, 6);
    var bv = -1, bn = 0; for (var k in s.bankVotes) if (s.bankVotes[k] > bn) { bn = s.bankVotes[k]; bv = +k; }
    var nm = SET_NAMES[s.first];
    if (nm) { s.kind = $t('Asterix & Obelix'); s.name = nm + ' ' + (++cnt.h); s.pal = K.HERO_PAL; s.bank = 0; }
    else if (bv >= 2) { s.kind = $t('Figuren'); s.name = $t('Figur ') + (++cnt.f); s.pal = -2; s.bank = bv; }
    else { s.kind = $t('Gegner'); s.name = $t('Gegner ') + (++cnt.e); s.pal = K.HERO_PAL; s.bank = 0; }
    s.name += ' (' + s.frames.length + ')';
  });
  return sets;
}
G.spriteCatalog = spriteCatalog;

/* ---------------------------------------------------------------- Sound */
/* Konfiguration (LS_Play-Nachfolger): Mix-Puffer, Laenge, Puffer, Laenge, Sample-Bank, Effekt-Tabelle.
   Sample-Bank: 256 x 12 Byte Kopf {u16 Laenge, s8 Feinstimmung, 0, u16 Lautstaerke, u16 Schleifenlaenge,
   u16 Schleifenstart, s16 Transponierung}, Daten direkt dahinter aneinander (8-Bit-PCM). */
function soundInfo() {
  var d = D(), cfg = K.SND_CFG, H = K.BANK_HDR;
  var bank = ptr(cfg + 16), sfx = ptr(cfg + 20), songs = [];
  for (var i = 0; i < K.SONG_COUNT; i++) songs.push({ idx: i, ref: K.SONG_TABLE + 4 * i, off: ptr(K.SONG_TABLE + 4 * i) });
  var samples = [], pos = bank + 256 * H;
  for (var k = 0; k < 256; k++) {
    var h = bank + H * k, w0 = G.u32(d, h), w1 = G.u32(d, h + 4), w2 = G.u32(d, h + 8), len = w0 & 0xFFFF;
    if (len) samples.push({ idx: k, hdr: h, len: len, data: pos, vol: w1 & 0xFFFF, fine: ((w0 >>> 16) & 0xFF) << 24 >> 24, fineRaw: (w0 >>> 16) & 0xFF,
      loopStart: w2 & 0xFFFF, loopLen: w1 >>> 16, rel: (w2 >>> 16) << 16 >> 16, w0: w0 });
    pos += len;
  }
  var nsfx = G.u32(d, sfx), sfxBase = sfx + 4 + 24 * nsfx, effects = [];
  for (var s = 0; s < nsfx && s < 512; s++) {
    var e = sfx + 4 + 24 * s;
    effects.push({ idx: s, ent: e, off: G.u32(d, e), len: G.u32(d, e + 4), vol: G.u32(d, e + 8), loop: G.u32(d, e + 12), rate: G.u32(d, e + 16), w5: G.u32(d, e + 20), data: sfxBase + G.u32(d, e) });
  }
  return { cfg: cfg, bank: bank, bankEnd: pos, hdrSize: 256 * H, sfx: sfx, sfxBase: sfxBase, samples: samples, effects: effects, songs: songs };
}
G.soundInfo = soundInfo;

/* ---------------------------------------------------------------- Zeiger */
function findRefs(off) {
  var d = D(), v = (0x08000000 + off) >>> 0, b0 = v & 255, b1 = (v >> 8) & 255, b2 = (v >> 16) & 255, b3 = v >>> 24, out = [];
  for (var o = 0; o + 3 < d.length; o += 4) if (d[o] === b0 && d[o + 1] === b1 && d[o + 2] === b2 && d[o + 3] === b3) out.push(o);
  return out;
}
function setPtr(at, off) { G.putU32(D(), at, 0x08000000 + off); }
G.findRefs = findRefs; G.setPtr = setPtr;

/* Daten ersetzen: passt es an den alten Platz, dort schreiben; sonst ans ROM-Ende verschieben und alle Verweise umbiegen. */
function replaceBlob(oldOff, oldSize, bytes, opts) {
  opts = opts || {};
  var r = G.App.rom, d = r.data;
  if (bytes.length <= oldSize && !opts.forceMove) {
    d.set(bytes, oldOff);
    if (opts.clearRest !== false) for (var i = oldOff + bytes.length; i < oldOff + oldSize; i++) d[i] = opts.fill || 0;
    return { off: oldOff, moved: false };
  }
  var refs = opts.refs || findRefs(oldOff);
  if (!refs.length && !opts.noRefsOk) throw new Error($t('Keine Verweise auf ') + G.hx(oldOff) + $t(' gefunden - Daten koennen nicht verschoben werden.'));
  var al = new G.Allocator(r, true), no = al.alloc(bytes.length + (opts.align || 0));
  if (no < 0) throw new Error($t('Kein Platz mehr in der ROM (auch nicht nach Erweiterung auf 16 MB).'));
  if (opts.align === 2 && (no & 1)) no++;
  r.data.set(bytes, no);
  refs.forEach(function (at) { setPtr(at, no); });
  return { off: no, moved: true, refs: refs.length };
}
G.replaceBlob = replaceBlob;
})(window);
