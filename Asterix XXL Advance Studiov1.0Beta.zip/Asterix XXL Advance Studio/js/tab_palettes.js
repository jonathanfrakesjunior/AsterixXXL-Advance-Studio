/* Asterix XXL Advance Studio - tab_palettes.js : Palettendateien bearbeiten */
(function (global) {
'use strict';
var G = global.AXS, el = G.el;
var state = { sel: 0, slot: -1 };

function fileColors(f) {
  var d = G.App.rom.data, out = [];
  f.recs.forEach(function (r) { for (var k = 0; k < r.n; k++) out.push({ slot: (r.dst >> 1) + k, at: r.off + 2 * k, c: G.c15ToRgb(G.u16(d, r.off + 2 * k)) }); });
  return out;
}

G.registerTab({
  id: 'palettes', label: $t('Paletten'), icon: '◐', group: $t('Grafik'), needsRom: true,
  render: function (v) {
    var files = G.cached('palfiles', G.paletteFiles);
    v.appendChild(el('h2', { text: $t('Paletten') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Alle Farbpaletten des Spiels (15 Bit, 32 Stufen je Kanal). Slots 0-255 = Hintergrund/Bitmap ') +
      $t('(Vollbilder, Menues), 256-511 = Objekte (Figuren, HUD, Himmel). Die Bodenpaletten der Level stehen in den Leveldateien (Level-Editor). Farbe anklicken zum Aendern.') }));
    var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '240px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
    var list = el('div', { class: 'list' });
    files.forEach(function (f, i) {
      list.appendChild(el('div', { class: 'it' + (i === state.sel ? ' sel' : ''), onclick: function () { state.sel = i; state.slot = -1; G.refreshTab(); } },
        [el('span', { class: 'grow', text: f.name }), el('small', { text: G.hex(f.off, 6) })]));
    });
    side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
    var f = files[state.sel]; if (!f) return;
    var cols = fileColors(f);
    main.appendChild(el('div', { class: 'toolbar' }, [el('b', { text: f.name }), el('span', { class: 'mut', text: f.recs.map(function (r) { return r.n + $t(' Farben ab Slot ') + (r.dst >> 1); }).join(', ') })]));
    f.recs.forEach(function (r) {
      var s0 = r.dst >> 1, g = el('div', { class: 'colgrid', style: { maxWidth: '520px' } });
      cols.filter(function (c) { return c.slot >= s0 && c.slot < s0 + r.n; }).forEach(function (c) {
        var sw = el('div', { class: 'sw' + (c.slot === state.slot ? ' sel' : ''), title: $t('Slot ') + c.slot + (c.slot >= 256 ? $t(' (Objekt ') + (c.slot - 256) + $t(', Bank ') + ((c.slot - 256) >> 4) + ')' : '') + ' - ' + G.hexColor(c.c), style: { background: G.hexColor(c.c) } });
        sw.onclick = function () {
          state.slot = c.slot;
          var inp = el('input', { type: 'color', value: G.hexColor(c.c), style: { position: 'fixed', left: '-100px' } });
          document.body.appendChild(inp);
          inp.onchange = function () {
            var rgb = G.parseHex(inp.value);
            G.putU16(G.App.rom.data, c.at, G.rgbToC15(rgb[0], rgb[1], rgb[2]));
            G.logChange(f.name + $t(' Slot ') + c.slot + ' -> ' + inp.value);
            inp.remove(); G.refreshTab();
          };
          inp.click();
        };
        g.appendChild(sw);
      });
      main.appendChild(el('div', { class: 'card' }, [el('h4', { text: (s0 >= 256 ? $t('Objektfarben ') + (s0 - 256) : $t('Hintergrundfarben ') + s0) + ' - ' + (s0 + r.n - 1 - (s0 >= 256 ? 256 : 0)) }), g]));
    });
    main.appendChild(el('div', { class: 'card' }, [el('h4', { text: $t('Austausch') }), el('div', { class: 'row' }, [
      G.button($t('JASC .pal exportieren'), function () { G.download('palette_' + G.hex(f.off, 6) + '.pal', new TextEncoder().encode(jascOut(cols))); }),
      G.button($t('PNG-Streifen exportieren'), function () {
        var n = cols.length, W = n * 8, rgba = new Uint8Array(W * 8 * 4);
        for (var y = 0; y < 8; y++) for (var x = 0; x < W; x++) { var c = cols[(x / 8) | 0].c, o = (y * W + x) * 4; rgba[o] = c[0]; rgba[o + 1] = c[1]; rgba[o + 2] = c[2]; rgba[o + 3] = 255; }
        G.download('palette_' + G.hex(f.off, 6) + '.png', G.pngWriteRGBA(rgba, W, 8), 'image/png');
      }),
      G.button($t('Importieren (.pal / .act / .png) ...'), async function () {
        var file = await G.pickFile('.pal,.act,.png,.gpl'); if (!file) return;
        try {
          var bytes = await G.readFileBytes(file), list = parsePalFile(bytes, file.name);
          var n = Math.min(list.length, cols.length);
          for (var i = 0; i < n; i++) G.putU16(G.App.rom.data, cols[i].at, G.rgbToC15(list[i][0], list[i][1], list[i][2]));
          G.logChange(f.name + ': ' + n + $t(' Farben importiert')); G.toast(n + $t(' Farben uebernommen.')); G.refreshTab();
        } catch (e) { G.toast(e.message, 'err'); }
      })
    ]), el('p', { class: 'hint', text: $t('Import fuellt die Farben der Reihe nach (in der Reihenfolge dieser Datei, ') + cols.length + $t(' Stueck).') })]));
  }
});

function jascOut(cols) { return 'JASC-PAL\r\n0100\r\n' + cols.length + '\r\n' + cols.map(function (c) { return c.c.join(' '); }).join('\r\n') + '\r\n'; }
function parsePalFile(bytes, name) {
  if (/\.png$/i.test(name)) {
    var p = G.pngRead(bytes); if (p.pal) return p.pal;
    var out = []; for (var x = 0; x < p.w; x += 8) out.push([p.rgba[x * 4], p.rgba[x * 4 + 1], p.rgba[x * 4 + 2]]); return out;
  }
  var txt = new TextDecoder().decode(bytes);
  if (/^JASC-PAL/.test(txt)) return txt.split(/\r?\n/).slice(3).filter(function (l) { return l.trim(); }).map(function (l) { return l.trim().split(/\s+/).map(Number); });
  if (/^GIMP Palette/.test(txt)) return txt.split(/\r?\n/).filter(function (l) { return /^\s*\d+\s+\d+\s+\d+/.test(l); }).map(function (l) { return l.trim().split(/\s+/).slice(0, 3).map(Number); });
  var o = []; for (var i = 0; i + 2 < Math.min(bytes.length, 768); i += 3) o.push([bytes[i], bytes[i + 1], bytes[i + 2]]); return o;
}
G.palettesExportAll = function (zip) {
  var files = G.cached('palfiles', G.paletteFiles);
  files.forEach(function (f) { zip.add('paletten/palette_' + G.hex(f.off, 6) + '.pal', new TextEncoder().encode(jascOut(fileColors(f)))); });
  return files.length;
};
G.palettesImportFile = function (name, bytes, report) {
  var m = /paletten\/palette_([0-9A-F]{6})\.pal$/i.exec(name); if (!m) return false;
  var f = G.cached('palfiles', G.paletteFiles).filter(function (x) { return x.off === parseInt(m[1], 16); })[0];
  if (!f) { report.skip.push(name + $t(': unbekannt')); return true; }
  var cols = fileColors(f), list = parsePalFile(bytes, name), ch = 0;
  for (var i = 0; i < Math.min(list.length, cols.length); i++) {
    var v = G.rgbToC15(list[i][0], list[i][1], list[i][2]);
    if (G.u16(G.App.rom.data, cols[i].at) !== v && G.rgbToC15.apply(null, cols[i].c) !== v) { G.putU16(G.App.rom.data, cols[i].at, v); ch++; }
  }
  if (ch) report.done.push(f.name + ' (' + ch + $t(' Farben)'));
  return true;
};
})(window);
